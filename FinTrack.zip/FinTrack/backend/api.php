<?php
include 'db_connect.php';

header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'GET') {
    $user_id = isset($_GET['user_id']) ? $_GET['user_id'] : 0;
    $sql = "SELECT * FROM transactions WHERE user_id=$user_id ORDER BY date DESC";
    $result = $conn->query($sql);

    $transactions = array();
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    echo json_encode(array("status" => "success", "data" => $transactions));

} elseif ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $user_id = $data['user_id'];
    $title = $data['title'];
    $amount = $data['amount'];
    $date = $data['date'];
    $note = isset($data['note']) ? $data['note'] : '';
    $type = $data['type'];
    $location = isset($data['location']) ? $data['location'] : '';
    $proof_image = isset($data['proof_image']) ? $data['proof_image'] : '';

    $stmt = $conn->prepare("INSERT INTO transactions (user_id, title, amount, date, note, type, location, proof_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isdissss", $user_id, $title, $amount, $date, $note, $type, $location, $proof_image);

    if ($stmt->execute()) {
        echo json_encode(array("status" => "success", "message" => "Transaction added successfully"));
    } else {
        echo json_encode(array("status" => "error", "message" => "Error: " . $stmt->error));
    }
    $stmt->close();
}

$conn->close();
?>