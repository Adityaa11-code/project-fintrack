<?php
$host = "localhost";
$user = "root";
$pass = "";
$db_name = "fintrack_db";

$conn = new mysqli($host, $user, $pass, $db_name);

if ($conn->connect_error) {
    die(json_encode(array("status" => "error", "message" => "Connection failed: " . $conn->connect_error)));
}
?>
