package com.example.fintrack

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

// Data Model adjusted for Firestore
data class NetworkTransaction(
    var id: String? = null,
    val title: String = "",
    val amount: Double = 0.0,
    val date: Long = 0L,
    val note: String? = null,
    val type: String = "", // "Pemasukan" or "Pengeluaran"
    val category: String? = null,
    val location: String? = null,
    val proofImage: String? = null,
    val userId: String? = null
)

data class NetworkTarget(
    var id: String? = null,
    val name: String = "",
    val amount: Double = 0.0,
    val durationMonths: Int = 0,
    val category: String = "",
    val note: String? = null,
    val photoStruct: String? = null, // Base64 image
    val location: String? = null,
    val userId: String? = null,
    val currentAmount: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

data class User(
    val id: String,
    val username: String,
    val email: String
)

data class AuthResponse(
    val status: String,
    val message: String? = null,
    val data: User? = null
)

data class ApiResponse(
    val status: String,
    val message: String? = null,
    val data: List<NetworkTransaction>? = null
)

object ApiClient {
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    fun getTransactions(userId: String, onResult: (ApiResponse) -> Unit) {
        db.collection("transactions")
            .whereEqualTo("userId", userId)
            //.orderBy("date", Query.Direction.DESCENDING) // Requires index in some cases, add later if needed or sort client side
            .get()
            .addOnSuccessListener { documents ->
                val list = mutableListOf<NetworkTransaction>()
                for (doc in documents) {
                    val t = doc.toObject(NetworkTransaction::class.java)
                    t.id = doc.id
                    list.add(t)
                }
                // Sort client side to avoid index requirement immediately
                list.sortByDescending { it.date }
                onResult(ApiResponse("success", data = list))
            }
            .addOnFailureListener {
                onResult(ApiResponse("error", message = it.message))
            }
    }

    fun addTransaction(transaction: NetworkTransaction, onResult: (ApiResponse) -> Unit) {
        db.collection("transactions")
            .add(transaction)
            .addOnSuccessListener {
                onResult(ApiResponse("success", message = "Transaksi berhasil disimpan"))
            }
            .addOnFailureListener {
                onResult(ApiResponse("error", message = it.message))
            }
    }

    fun login(email: String, password: String, onResult: (AuthResponse) -> Unit) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val user = result.user
                // Fetch extra data (username) if stored in separate users collection, 
                // but for now we'll just use email prefix or display name if available.
                // Or we can query the 'users' collection if we migrate that too.
                // Assuming we migrate 'users' table to 'users' collection.
                if (user != null) {
                    db.collection("users").document(user.uid).get()
                        .addOnSuccessListener { doc ->
                           val username = doc.getString("username") ?: user.email?.substringBefore("@") ?: "User"
                           onResult(AuthResponse("success", data = User(user.uid, username, user.email ?: "")))     
                        }
                        .addOnFailureListener {
                            // Fallback if user doc not found
                            onResult(AuthResponse("success", data = User(user.uid, user.email?.substringBefore("@") ?: "User", user.email ?: "")))
                        }
                } else {
                     onResult(AuthResponse("error", message = "User null"))
                }
            }
            .addOnFailureListener {
                onResult(AuthResponse("error", message = it.message))
            }
    }

    fun register(username: String, email: String, pass: String, onResult: (AuthResponse) -> Unit) {
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnSuccessListener { result ->
                val user = result.user
                if (user != null) {
                    // Save additional user info
                    val userData = mapOf(
                        "username" to username,
                        "email" to email,
                        "created_at" to System.currentTimeMillis()
                    )
                    db.collection("users").document(user.uid).set(userData)
                        .addOnSuccessListener {
                             onResult(AuthResponse("success", data = User(user.uid, username, email)))
                        }
                        .addOnFailureListener {
                             onResult(AuthResponse("success", message = "Register auth success but db failed: ${it.message}", data = User(user.uid, username, email)))
                        }
                }
            }
            .addOnFailureListener {
                onResult(AuthResponse("error", message = it.message))
            }
    }

    fun addTarget(target: NetworkTarget, onResult: (ApiResponse) -> Unit) {
        db.collection("targets")
            .add(target)
            .addOnSuccessListener {
                onResult(ApiResponse("success", message = "Target berhasil disimpan"))
            }
            .addOnFailureListener {
                onResult(ApiResponse("error", message = it.message))
            }
    }

    fun getTargets(userId: String, onResult: (List<NetworkTarget>) -> Unit) {
        db.collection("targets")
            .whereEqualTo("userId", userId)
            .get()
            .addOnSuccessListener { documents ->
                val list = mutableListOf<NetworkTarget>()
                for (doc in documents) {
                    val t = doc.toObject(NetworkTarget::class.java)
                    t.id = doc.id
                    list.add(t)
                }
                onResult(list)
            }
            .addOnFailureListener {
                onResult(emptyList())
            }
    }
    fun updateTarget(target: NetworkTarget, onResult: (ApiResponse) -> Unit) {
        if (target.id == null) {
            onResult(ApiResponse("error", message = "Target ID missing"))
            return
        }
        db.collection("targets").document(target.id!!)
            .set(target)
            .addOnSuccessListener {
                onResult(ApiResponse("success", message = "Target updated"))
            }
            .addOnFailureListener {
                onResult(ApiResponse("error", message = it.message))
            }
    }

    fun deleteTarget(targetId: String, onResult: (ApiResponse) -> Unit) {
        db.collection("targets").document(targetId)
            .delete()
            .addOnSuccessListener {
                onResult(ApiResponse("success", message = "Target deleted"))
            }
            .addOnFailureListener {
                onResult(ApiResponse("error", message = it.message))
            }
    }
}
