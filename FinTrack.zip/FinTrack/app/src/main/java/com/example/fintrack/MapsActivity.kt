package com.example.fintrack

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.util.Locale

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var selectedLatLng: LatLng? = null
    private var selectedAddress: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val btnSelectLocation = findViewById<Button>(R.id.btnSelectLocation)
        btnSelectLocation.setOnClickListener {
            if (selectedAddress != null) {
                val intent = Intent()
                intent.putExtra("address", selectedAddress)
                setResult(RESULT_OK, intent)
                finish()
            } else {
                Toast.makeText(this, "Silakan pilih lokasi terlebih dahulu", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
            
            // Get current location to move camera
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    val currentLatLng = LatLng(location.latitude, location.longitude)
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15f))
                    getAddressFromLatLng(currentLatLng) // Initial address
                }
            }
        }

        mMap.setOnMapClickListener { latLng ->
            mMap.clear()
            mMap.addMarker(MarkerOptions().position(latLng).title("Lokasi Dipilih"))
            selectedLatLng = latLng
            getAddressFromLatLng(latLng)
        }
    }

    private fun getAddressFromLatLng(latLng: LatLng) {
        try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
            if (!addresses.isNullOrEmpty()) {
                val address = addresses[0]
                val sb = StringBuilder()
                if (address.featureName != null) sb.append(address.featureName).append(", ")
                if (address.thoroughfare != null) sb.append(address.thoroughfare).append(", ")
                if (address.locality != null) sb.append(address.locality)
                
                selectedAddress = if (sb.isEmpty()) {
                    "Lat: ${latLng.latitude}, Lon: ${latLng.longitude}"
                } else {
                    "📍 " + sb.toString()
                }
                Toast.makeText(this, "Lokasi: $selectedAddress", Toast.LENGTH_SHORT).show()
                selectedLatLng = latLng
            }
        } catch (e: Exception) {
            e.printStackTrace()
            selectedAddress = "Lat: ${latLng.latitude}, Lon: ${latLng.longitude}"
        }
    }
}
