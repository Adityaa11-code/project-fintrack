package com.example.fintrack

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.MediaStore
import androidx.core.app.ActivityCompat
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.app.AlertDialog
import android.content.DialogInterface
import android.graphics.Color
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.Observer
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Tip(val title: String, val description: String, val color: String, val icon: String)
data class Transaction(
    val id: String, // Changed to String for Firebase
    val title: String,
    val amount: Double,
    val date: Date,
    val note: String,
    val type: String, // "Pemasukan" or "Pengeluaran"
    val category: String = "Lain-lain",
    val proofImage: Bitmap? = null,
    val location: String? = null
)

class MainActivity : AppCompatActivity() {

    private lateinit var viewPagerTips: ViewPager2
    private lateinit var tabLayoutDots: TabLayout
    private val tipsHandler = Handler(Looper.getMainLooper())
    private var currentPage = 0
    private val transactionList = mutableListOf<Transaction>()
    private lateinit var targetViewModel: TargetViewModel
    
    // Camera Logic
    private val CAMERA_REQUEST_CODE = 100
    private val LOCATION_REQUEST_CODE = 101
    private val MAPS_REQUEST_CODE = 102
    private val GALLERY_REQUEST_CODE = 103
    private var currentDialog: Dialog? = null
    private var currentProofBitmap: Bitmap? = null
    private var currentLocationString: String? = null
    
    private var isLoggedIn = false
    private var validUsername = "User"
    
    // Base64 Helpers
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val byteArrayOutputStream = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        return android.util.Base64.encodeToString(byteArray, android.util.Base64.DEFAULT)
    }

    private fun base64ToBitmap(base64Str: String): Bitmap? {
        return try {
            val decodedBytes = android.util.Base64.decode(base64Str, android.util.Base64.DEFAULT)
            BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
        } catch (e: Exception) {
            null
        }
    }



    private fun fetchTransactionsFromApi() {
        val user = ApiClient.auth.currentUser
        val userId = user?.uid

        // Don't fetch if not logged in
        if (userId == null) return

        ApiClient.getTransactions(userId) { response ->
            if (response.status == "success") {
                val networkList = response.data
                if (networkList != null) {
                    transactionList.clear()
                    for (netTrans in networkList) {
                        val trans = Transaction(
                            id = netTrans.id ?: "",
                            title = netTrans.title,
                            amount = netTrans.amount,
                            date = java.util.Date(netTrans.date),
                            note = netTrans.note ?: "",
                            type = netTrans.type,
                            category = netTrans.category ?: "Lain-lain",
                            location = netTrans.location,
                            proofImage = if (!netTrans.proofImage.isNullOrEmpty()) base64ToBitmap(netTrans.proofImage) else null
                        )
                        transactionList.add(trans)
                    }
                    updateDashboard()
                }
            } else {
                Toast.makeText(this@MainActivity, "Gagal memuat: ${response.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        
        targetViewModel = ViewModelProvider(this)[TargetViewModel::class.java]
        targetViewModel.toastMessage.observe(this) { message ->
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setupMenuClickListeners()
        
        // Check Auth State
        val currentUser = ApiClient.auth.currentUser
        if (currentUser != null) {
            isLoggedIn = true
            val prefs = getSharedPreferences("FinTrackPrefs", MODE_PRIVATE)
            validUsername = prefs.getString("username", currentUser.email ?: "User") ?: "User"
            findViewById<TextView>(R.id.tvLoginPrompt).text = "Halo, $validUsername"
        }

        setupTipsCarousel()
        updateDashboard()
        fetchTransactionsFromApi() // Load data from server
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as? Bitmap
            if (imageBitmap != null) {
                currentProofBitmap = imageBitmap
                updateProofUI()
                updateTargetProofUI()
            }
        } else if (requestCode == MAPS_REQUEST_CODE && resultCode == RESULT_OK) {
            val address = data?.getStringExtra("address")
            if (address != null) {
                currentLocationString = address
                val dialog = currentDialog
                if (dialog != null) {
                     // Try finding the text view in both dialogs, purely based on ID existence
                     val tvLocationResult = dialog.findViewById<TextView>(R.id.tvLocationResult)
                     val tvTargetLocationResult = dialog.findViewById<TextView>(R.id.tvTargetLocationResult)
                     
                     if (tvLocationResult != null) {
                         tvLocationResult.text = currentLocationString
                         tvLocationResult.setTextColor(Color.parseColor("#4CAF50"))
                     }
                     if (tvTargetLocationResult != null) {
                         tvTargetLocationResult.text = currentLocationString
                         tvTargetLocationResult.setTextColor(Color.parseColor("#4CAF50"))
                     }
                }
            }
        } else if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            val selectedImage = data?.data
            if (selectedImage != null) {
                try {
                    val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, selectedImage)
                    currentProofBitmap = bitmap
                    updateProofUI()
                    updateTargetProofUI()
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Izin lokasi ditolak", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getCurrentLocation() {
        val dialog = currentDialog ?: return
        
        // Find TextViews for both dialog types
        val tvLocationResult = dialog.findViewById<TextView>(R.id.tvLocationResult)
        val tvTargetLocationResult = dialog.findViewById<TextView>(R.id.tvTargetLocationResult)
        
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        try {
            val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = locationManager.getProviders(true)
            var bestLocation: Location? = null
            
            for (provider in providers) {
                val l = locationManager.getLastKnownLocation(provider) ?: continue
                if (bestLocation == null || l.accuracy < bestLocation.accuracy) {
                    bestLocation = l
                }
            }

            if (bestLocation != null) {
                val geocoder = Geocoder(this, Locale.getDefault())
                val addresses = geocoder.getFromLocation(bestLocation.latitude, bestLocation.longitude, 1)
                
                // Update whichever TextView is available
                if (tvLocationResult != null) {
                    updateLocationUI(addresses, bestLocation.latitude, bestLocation.longitude, tvLocationResult)
                }
                if (tvTargetLocationResult != null) {
                    updateLocationUI(addresses, bestLocation.latitude, bestLocation.longitude, tvTargetLocationResult)
                }
            } else {
                 Toast.makeText(this, "Lokasi tidak ditemukan, pastikan GPS aktif", Toast.LENGTH_SHORT).show()
                 tvLocationResult?.text = "Gagal mengambil lokasi"
                 tvTargetLocationResult?.text = "Gagal mengambil lokasi"
            }
        } catch (e: Exception) {
            e.printStackTrace()
             val errorMsg = e.message ?: e::class.java.simpleName
             Toast.makeText(this, "Error mengambil lokasi: $errorMsg", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun showSearchLocationInput(dialog: Dialog) {
        val input = EditText(this)
        input.hint = "Cari nama tempat (misal: Grand Indonesia)"
        
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(50, 20, 50, 20)
        input.layoutParams = params
        container.addView(input)
        
        AlertDialog.Builder(this)
            .setTitle("Cari Lokasi")
            .setView(container)
            .setPositiveButton("Cari") { _, _ ->
                val query = input.text.toString().trim()
                if (query.isNotEmpty()) {
                    searchLocation(query, dialog)
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }
    
    private fun searchLocation(query: String, dialog: Dialog) {
        try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocationName(query, 1)
            val tvLocationResult = dialog.findViewById<TextView>(R.id.tvLocationResult)
            
            
            if (!addresses.isNullOrEmpty()) {
                val address = addresses[0]
                
                if (tvLocationResult != null) {
                    updateLocationUI(addresses, address.latitude, address.longitude, tvLocationResult)
                }
                
                val tvTargetLocationResult = dialog.findViewById<TextView>(R.id.tvTargetLocationResult)
                if (tvTargetLocationResult != null) {
                    updateLocationUI(addresses, address.latitude, address.longitude, tvTargetLocationResult)
                }
            } else {
                Toast.makeText(this, "Lokasi tidak ditemukan", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
             Toast.makeText(this, "Error mencari lokasi: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun updateLocationUI(addresses: List<android.location.Address>?, lat: Double, lon: Double, tvLocationResult: TextView?) {
         if (tvLocationResult == null) return

         if (!addresses.isNullOrEmpty()) {
            val address = addresses!![0]
            val sb = StringBuilder()
            if (address.featureName != null) sb.append(address.featureName).append(", ")
            if (address.thoroughfare != null) sb.append(address.thoroughfare).append(", ")
            if (address.locality != null) sb.append(address.locality)
            
            if (sb.isEmpty()) {
                 currentLocationString = "Lat: $lat, Lon: $lon"
            } else {
                 currentLocationString = "📍 " + sb.toString()
            }
        } else {
            currentLocationString = "📍 Lat: $lat, Lon: $lon"
        }
        tvLocationResult.text = currentLocationString
        tvLocationResult.setTextColor(Color.parseColor("#4CAF50"))
    }
    
    private fun updateProofUI() {
        val dialog = currentDialog ?: return
        val ivBuktiPreview = dialog.findViewById<ImageView>(R.id.ivBuktiPreview) ?: return
        val layoutBuktiPlaceholder = dialog.findViewById<View>(R.id.layoutBuktiPlaceholder) ?: return
        val ivRemoveBukti = dialog.findViewById<View>(R.id.ivRemoveBukti) ?: return
        
        if (currentProofBitmap != null) {
            ivBuktiPreview.setImageBitmap(currentProofBitmap)
            ivBuktiPreview.visibility = View.VISIBLE
            ivRemoveBukti.visibility = View.VISIBLE
            layoutBuktiPlaceholder.visibility = View.GONE
        } else {
            ivBuktiPreview.visibility = View.GONE
            ivRemoveBukti.visibility = View.GONE
            layoutBuktiPlaceholder.visibility = View.VISIBLE
        }
    }

    private fun updateTargetProofUI() {
        val dialog = currentDialog ?: return
        val ivTargetFotoPreview = dialog.findViewById<ImageView>(R.id.ivTargetFotoPreview) ?: return
        val layoutTargetFotoPlaceholder = dialog.findViewById<View>(R.id.layoutTargetFotoPlaceholder) ?: return
        val ivRemoveTargetFoto = dialog.findViewById<View>(R.id.ivRemoveTargetFoto) ?: return

        if (currentProofBitmap != null) {
            ivTargetFotoPreview.setImageBitmap(currentProofBitmap)
            ivTargetFotoPreview.visibility = View.VISIBLE
            ivRemoveTargetFoto.visibility = View.VISIBLE
            layoutTargetFotoPlaceholder.visibility = View.GONE
        } else {
            ivTargetFotoPreview.visibility = View.GONE
            ivRemoveTargetFoto.visibility = View.GONE
            layoutTargetFotoPlaceholder.visibility = View.VISIBLE
        }
    }

    private fun updateCategoryChips(dialog: Dialog, type: String) {
        val chipGroup = dialog.findViewById<ChipGroup>(R.id.chipGroupKategori)
        val etKategoriCustom = dialog.findViewById<EditText>(R.id.etKategoriCustom)
        chipGroup.removeAllViews()

        val categories = if (type == "Pengeluaran") {
            listOf("Makanan & Minuman", "Transportasi", "Investasi & Tabungan", "Lain-lain")
        } else {
            listOf("Gaji/Penghasilan Tetap", "Investasi & Pasif", "Penghasilan Sampingan", "Lain-lain")
        }

        for (category in categories) {
            val chip = Chip(this)
            chip.text = category
            chip.isCheckable = true
            chip.setOnClickListener {
                etKategoriCustom.setText(category)
            }
            chip.setTextColor(Color.WHITE)
            chip.setChipBackgroundColorResource(R.color.purple_500)
            chipGroup.addView(chip)
        }
    }


    private fun setupMenuClickListeners() {
        findViewById<TextView>(R.id.tvLoginPrompt).setOnClickListener {
            if (isLoggedIn) {
                showProfileDialog()
            } else {
                showLoginRegisterDialog()
            }
        }
        findViewById<CardView>(R.id.cardTambahTransaksi).setOnClickListener { showAddTransactionDialog() }
        findViewById<CardView>(R.id.cardHistori).setOnClickListener { showHistoryDialog() }
        findViewById<CardView>(R.id.cardPlanning).setOnClickListener { showPlanningDialog() }
        findViewById<CardView>(R.id.cardAnalisis).setOnClickListener { showFinancialAnalysisDialog() }
        
        findViewById<Button>(R.id.btnPemasukan).setOnClickListener { toggleDropdown("Pemasukan") }
        findViewById<Button>(R.id.btnPengeluaran).setOnClickListener { toggleDropdown("Pengeluaran") }
    }

    private fun setupTipsCarousel() {
        viewPagerTips = findViewById(R.id.viewPagerTips)
        tabLayoutDots = findViewById(R.id.tabLayoutDots)

        val tipsList = listOf(
            Tip("💡 Tip Hemat", "Sisihkan 20% gaji untuk darurat", "#0D3A26", ""),
            Tip("🎯 Target Bulan Ini", "Hemat uang makan Rp 500rb", "#0D263A", ""),
            Tip("📈 Analisis Pengeluaran", "Hiburan naik 15%, ayo kurangi!", "#3A2A0D", ""),
            Tip("❗️ Reminder", "Bayar listrik sebelum tgl 20", "#401C1C", ""),
            Tip("💡 Investasi Cerdas", "Investasi reksa dana 10rb/hari", "#0D3A26", "")
        )

        viewPagerTips.adapter = TipsAdapter(tipsList)
        TabLayoutMediator(tabLayoutDots, viewPagerTips) { _, _ -> }.attach()

        val autoScrollRunnable = object : Runnable {
            override fun run() {
                if (currentPage == tipsList.size) {
                    currentPage = 0
                }
                viewPagerTips.setCurrentItem(currentPage++, true)
                tipsHandler.postDelayed(this, 5000)
            }
        }

        tipsHandler.postDelayed(autoScrollRunnable, 5000)
    }

    private fun updateDashboard() {
        val totalIncome = transactionList.filter { it.type == "Pemasukan" }.sumOf { it.amount }
        val totalExpense = transactionList.filter { it.type == "Pengeluaran" }.sumOf { it.amount }
        val balance = totalIncome - totalExpense

        val format = NumberFormat.getCurrencyInstance(Locale("in", "ID"))

        findViewById<TextView>(R.id.tvTotalSaldo).text = format.format(balance)
        findViewById<Button>(R.id.btnPemasukan).text = "Pemasukan Terakhir   ${format.format(totalIncome)} ▼"
        findViewById<Button>(R.id.btnPengeluaran).text = "Pengeluaran Terakhir   ${format.format(totalExpense)} ▼"

        // --- AI Insight Update ---
        try {
            val aiAnalyzer = AiAnalyzer(transactionList)
            val advice = aiAnalyzer.getAiAdvice()
            val prediction = aiAnalyzer.predictEndOfMonthExpense()
            
            findViewById<TextView>(R.id.tvAiAdvice).text = advice
            findViewById<TextView>(R.id.tvAiPrediction).text = "Est. Pengeluaran Akhir Bulan: ${format.format(prediction)}"
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAddTransactionDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_add_transaction)
        currentDialog = dialog
        currentProofBitmap = null // Reset proof
        currentLocationString = null // Reset location


        val tvTanggal = dialog.findViewById<TextView>(R.id.tvTanggal)
        val toggleGroup = dialog.findViewById<MaterialButtonToggleGroup>(R.id.toggleGroup)
        val btnSimpan = dialog.findViewById<Button>(R.id.btnSimpan)
        val btnClose = dialog.findViewById<ImageView>(R.id.btnClose)

        btnClose.setOnClickListener {
            dialog.dismiss()
        }
        val etJudulTransaksi = dialog.findViewById<EditText>(R.id.etJudulTransaksi)
        val etNominal = dialog.findViewById<EditText>(R.id.etNominal)
        val etCatatan = dialog.findViewById<EditText>(R.id.etCatatan)
        
        val layoutBuktiPlaceholder = dialog.findViewById<LinearLayout>(R.id.layoutBuktiPlaceholder)
        val ivRemoveBukti = dialog.findViewById<ImageView>(R.id.ivRemoveBukti)
        
        layoutBuktiPlaceholder.setOnClickListener {
            val options = arrayOf("Ambil Foto (Kamera)", "Pilih dari Galeri")
            AlertDialog.Builder(this)
                .setTitle("Tambah Bukti Transaksi")
                .setItems(options) { _, which ->
                    if (which == 0) {
                        // Camera
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST_CODE)
                        } else {
                            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                            if (cameraIntent.resolveActivity(packageManager) != null) {
                                startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
                            } else {
                                Toast.makeText(this, "Kamera tidak tersedia", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        // Gallery
                        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE)
                    }
                }
                .show()
        }
        
        ivRemoveBukti.setOnClickListener {
            currentProofBitmap = null
            updateProofUI()
        }
        
        val btnGetLocation = dialog.findViewById<Button>(R.id.btnGetLocation)
        btnGetLocation.setOnClickListener {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                 ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), LOCATION_REQUEST_CODE)
            } else {
                getCurrentLocation()
            }
        }
        
        val btnSearchLocation = dialog.findViewById<Button>(R.id.btnSearchLocation)
        btnSearchLocation.setOnClickListener {
            showSearchLocationInput(dialog)
        }
        
        val btnOpenMap = dialog.findViewById<Button>(R.id.btnOpenMap)
        btnOpenMap.setOnClickListener {
             if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                 ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), LOCATION_REQUEST_CODE)
            } else {
                val intent = Intent(this, MapsActivity::class.java)
                startActivityForResult(intent, MAPS_REQUEST_CODE)
            }
        }


        // --- CALENDAR LOGIC START ---
        val calendar = Calendar.getInstance()
        val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("in", "ID"))

        // Set initial date to today
        tvTanggal.text = sdf.format(calendar.time)

        tvTanggal.setOnClickListener {
            val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                tvTanggal.text = sdf.format(calendar.time)
            }

            DatePickerDialog(this, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show()
        }
        // --- CALENDAR LOGIC END ---

        toggleGroup.check(R.id.btnPengeluaran)
        btnSimpan.text = "Simpan Pengeluaran"
        btnSimpan.background = ContextCompat.getDrawable(this, R.drawable.bg_button_red)

        toggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                when (checkedId) {
                    R.id.btnPengeluaran -> {
                        btnSimpan.text = "Simpan Pengeluaran"
                        btnSimpan.background = ContextCompat.getDrawable(this, R.drawable.bg_button_red)
                        updateCategoryChips(dialog, "Pengeluaran")
                    }
                    R.id.btnPemasukan -> {
                        btnSimpan.text = "Simpan Pemasukan"
                        btnSimpan.background = ContextCompat.getDrawable(this, R.drawable.bg_button_green)
                        updateCategoryChips(dialog, "Pemasukan")
                    }
                }
            }
        }
        
        // Initial population
        updateCategoryChips(dialog, "Pengeluaran")

        btnSimpan.setOnClickListener {
            val judul = etJudulTransaksi.text.toString().trim()
            val nominalStr = etNominal.text.toString().trim()
            val catatan = etCatatan.text.toString().trim()
            val jenis = if (toggleGroup.checkedButtonId == R.id.btnPemasukan) "Pemasukan" else "Pengeluaran"

            if (judul.isEmpty()) {
                etJudulTransaksi.error = "Judul tidak boleh kosong"
                return@setOnClickListener
            }

            if (nominalStr.isEmpty()) {
                etNominal.error = "Nominal tidak boleh kosong"
                return@setOnClickListener
            }

            val nominal = nominalStr.toDoubleOrNull()
            if (nominal == null || nominal <= 0) {
                etNominal.error = "Nominal tidak valid"
                return@setOnClickListener
            }

            val userId = ApiClient.auth.currentUser?.uid

            if (userId == null) {
                 Toast.makeText(this, "Silakan login terlebih dahulu", Toast.LENGTH_SHORT).show()
                 return@setOnClickListener
            }

            val etKategoriCustom = dialog.findViewById<EditText>(R.id.etKategoriCustom)
            val kategori = etKategoriCustom.text.toString().trim().ifEmpty { "Lain-lain" }

            val proofString = if (currentProofBitmap != null) bitmapToBase64(currentProofBitmap!!) else ""
            val netTrans = NetworkTransaction(
                title = judul,
                amount = nominal,
                date = calendar.timeInMillis,
                note = catatan,
                type = jenis,
                category = kategori,
                location = currentLocationString,
                proofImage = proofString,
                userId = userId
            )

            ApiClient.addTransaction(netTrans) { response ->
                if (response.status == "success") {
                    Toast.makeText(this@MainActivity, "Disimpan di Server", Toast.LENGTH_SHORT).show()
                    currentProofBitmap = null
                    currentLocationString = null
                    fetchTransactionsFromApi() // Refresh list
                    dialog.dismiss()
                } else {
                    Toast.makeText(this@MainActivity, "Gagal simpan: ${response.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        dialog.show()
    }

    private fun showHistoryDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_history)

        val rvHistory = dialog.findViewById<RecyclerView>(R.id.rvHistory)
        val tvNoTransactions = dialog.findViewById<TextView>(R.id.tvNoTransactions)
        val toggleGroup = dialog.findViewById<MaterialButtonToggleGroup>(R.id.toggleGroupHistory)
        val tvTransaksiPeriod = dialog.findViewById<TextView>(R.id.tvTransaksiPeriod)
        val btnClose = dialog.findViewById<ImageView>(R.id.btnClose)

        toggleGroup.check(R.id.btnHarian)
        tvTransaksiPeriod.text = "Transaksi Hari Ini"

        fun filterAndShow(type: String) {
            val calendar = Calendar.getInstance()
            val filteredList = transactionList.filter {
                val transactionDate = Calendar.getInstance()
                transactionDate.time = it.date

                when (type) {
                    "Harian" -> {
                        calendar.get(Calendar.YEAR) == transactionDate.get(Calendar.YEAR) &&
                        calendar.get(Calendar.DAY_OF_YEAR) == transactionDate.get(Calendar.DAY_OF_YEAR)
                    }
                    "Mingguan" -> {
                        calendar.get(Calendar.YEAR) == transactionDate.get(Calendar.YEAR) &&
                        calendar.get(Calendar.WEEK_OF_YEAR) == transactionDate.get(Calendar.WEEK_OF_YEAR)
                    }
                    "Bulanan" -> {
                        calendar.get(Calendar.YEAR) == transactionDate.get(Calendar.YEAR) &&
                        calendar.get(Calendar.MONTH) == transactionDate.get(Calendar.MONTH)
                    }
                    "Semua" -> true
                    else -> false
                }
            }.sortedByDescending { it.date }

            if (filteredList.isEmpty()) {
                rvHistory.visibility = View.GONE
                tvNoTransactions.visibility = View.VISIBLE
            } else {
                rvHistory.visibility = View.VISIBLE
                tvNoTransactions.visibility = View.GONE
                rvHistory.layoutManager = LinearLayoutManager(this)
                rvHistory.adapter = TransactionAdapter(filteredList) { bitmap ->
                    showImagePreviewDialog(bitmap)
                }
            }
        }

        // Initial load
        filterAndShow("Harian")

        toggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                when (checkedId) {
                    R.id.btnHarian -> {
                        tvTransaksiPeriod.text = "Transaksi Hari Ini"
                        filterAndShow("Harian")
                    }
                    R.id.btnMingguan -> {
                        tvTransaksiPeriod.text = "Transaksi Minggu Ini"
                        filterAndShow("Mingguan")
                    }
                    R.id.btnBulanan -> {
                        tvTransaksiPeriod.text = "Transaksi Bulan Ini"
                        filterAndShow("Bulanan")
                    }
                    R.id.btnSemua -> {
                        tvTransaksiPeriod.text = "Semua Riwayat Transaksi"
                        filterAndShow("Semua")
                    }
                }
            }
        }

        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun toggleDropdown(type: String) {
        val rvDropdown = if (type == "Pemasukan") findViewById<RecyclerView>(R.id.rvIncomeDropdown) else findViewById<RecyclerView>(R.id.rvExpenseDropdown)
        val otherDropdown = if (type == "Pemasukan") findViewById<RecyclerView>(R.id.rvExpenseDropdown) else findViewById<RecyclerView>(R.id.rvIncomeDropdown)
        
        // Close other dropdown if open
        if (otherDropdown.visibility == View.VISIBLE) {
            otherDropdown.visibility = View.GONE
        }

        if (rvDropdown.visibility == View.VISIBLE) {
            android.transition.TransitionManager.beginDelayedTransition(findViewById(R.id.main))
            rvDropdown.visibility = View.GONE
        } else {

            // Filter data: Sort by date descending, take top 3
            val filteredTransactions = transactionList
                .filter { it.type == type }
                .sortedByDescending { it.date }
                .take(3)

            if (filteredTransactions.isNotEmpty()) {
                rvDropdown.layoutManager = LinearLayoutManager(this)
                rvDropdown.adapter = TransactionAdapter(filteredTransactions) { bitmap ->
                    showImagePreviewDialog(bitmap)
                }
                
                android.transition.TransitionManager.beginDelayedTransition(findViewById(R.id.main))
                rvDropdown.visibility = View.VISIBLE
            } else {
                Toast.makeText(this, "Tidak ada transaksi $type", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showAddSavingsDialog(target: NetworkTarget) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(50, 40, 50, 40)
        container.setBackgroundColor(Color.parseColor("#1E1E1E")) // Dark Background
        
        // Title
        val tvTitle = TextView(this)
        tvTitle.text = "Tambah Tabungan ke ${target.name}"
        tvTitle.textSize = 18f
        tvTitle.setTextColor(Color.WHITE) // White Text
        tvTitle.typeface = android.graphics.Typeface.DEFAULT_BOLD
        container.addView(tvTitle)
        
        // Input
        val input = EditText(this)
        input.hint = "Masukkan Nominal"
        input.setHintTextColor(Color.parseColor("#B0BEC5")) // Light Grey Hint
        input.setTextColor(Color.WHITE) // White Input Text
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(0, 30, 0, 30)
        input.layoutParams = params
        
        // Fix for input underline color on dark background (Optional, but good for visibility)
        val colorStateList = ColorStateList.valueOf(Color.parseColor("#4CAF50"))
        ViewCompat.setBackgroundTintList(input, colorStateList)
        
        container.addView(input)
        
        // Buttons
        val btnLayout = LinearLayout(this)
        btnLayout.orientation = LinearLayout.HORIZONTAL
        btnLayout.gravity = android.view.Gravity.END
        
        val btnCancel = Button(this, null, android.R.attr.borderlessButtonStyle)
        btnCancel.text = "Batal"
        btnCancel.setTextColor(Color.parseColor("#EF5350")) // Red for Cancel
        btnCancel.setOnClickListener { dialog.dismiss() }
        
        val btnOk = Button(this, null, android.R.attr.borderlessButtonStyle)
        btnOk.text = "Simpan"
        btnOk.setTextColor(Color.parseColor("#4CAF50")) // Green for Save
        btnOk.setOnClickListener {
            val amountStr = input.text.toString().trim()
            if (amountStr.isEmpty()) {
                input.error = "Wajib diisi"
                return@setOnClickListener
            }
            val amount = amountStr.toDoubleOrNull()
            if (amount == null || amount <= 0) {
                 input.error = "Nominal tidak valid"
                 return@setOnClickListener
            }
            
            // Logic: 
            // 1. Create Expense Transaction
            // 2. Update Target amount
            
            // Cap amount to remaining needed
            val remainingNeeded = target.amount - target.currentAmount
            val actualSaveAmount: Double
            val refundAmount: Double
            
            if (amount > remainingNeeded) {
                actualSaveAmount = remainingNeeded
                refundAmount = amount - remainingNeeded
            } else {
                actualSaveAmount = amount
                refundAmount = 0.0
            }
            
            if (actualSaveAmount <= 0) {
                 Toast.makeText(this, "Target sudah tercapai!", Toast.LENGTH_SHORT).show()
                 return@setOnClickListener
            }
            
            
            val userId = ApiClient.auth.currentUser?.uid ?: return@setOnClickListener
            
            // Call ViewModel
            targetViewModel.addSavings(target, amount, userId)
        }
        
        // Observe status to close dialog
        val statusObserver = Observer<String?> { status ->
             if (status == "success_save") {
                 dialog.dismiss()
                 targetViewModel.clearOperationStatus()
                 
                 // Refresh dashboard (Activity logic remains here for convenience or move to Observer in onCreate)
                 updateDashboard()
                 fetchTransactionsFromApi() 
                 
                 // Since showPlanningDialog listens to targets, it will auto update if open.
             }
        }
        targetViewModel.operationStatus.observe(this, statusObserver)
        dialog.setOnDismissListener { targetViewModel.operationStatus.removeObserver(statusObserver) }
        
        btnLayout.addView(btnCancel)
        btnLayout.addView(btnOk)
        container.addView(btnLayout)
        
        dialog.setContentView(container)
        dialog.show()
    }

    private fun showPlanningDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_planning_target)

        val toggleGroup = dialog.findViewById<MaterialButtonToggleGroup>(R.id.toggleGroup)
        val btnTargetSaya = dialog.findViewById<MaterialButton>(R.id.btnTargetSaya)
        val btnBuatTargetBaru = dialog.findViewById<MaterialButton>(R.id.btnBuatTargetBaru)
        val layoutTargetSaya = dialog.findViewById<LinearLayout>(R.id.layoutTargetSaya)
        val layoutBuatTargetBaru = dialog.findViewById<LinearLayout>(R.id.layoutBuatTargetBaru)
        val ivClose = dialog.findViewById<ImageView>(R.id.ivClose)
        
        // Target list views
        val rvTargets = dialog.findViewById<RecyclerView>(R.id.rvTargets)
        val tvNoTargets = dialog.findViewById<TextView>(R.id.tvNoTargets)

        // Reset state
        currentDialog = dialog
        currentProofBitmap = null
        currentLocationString = null

        val purpleColor = ColorStateList.valueOf(Color.parseColor("#9C27B0"))
        val grayColor = ColorStateList.valueOf(Color.parseColor("#888888"))

        // --- Category Spinner Setup ---
        val spinnerKategoriTarget = dialog.findViewById<Spinner>(R.id.spinnerKategoriTarget)
        val categories = arrayOf(
            "Makanan & Minuman",
            "Transportasi",
            "Investasi & Tabungan",
            "Belanja",
            "Hiburan",
            "Pendidikan",
            "Kesehatan",
            "Lain-lain"
        )
        val adapter = ArrayAdapter(this, R.layout.item_spinner_white, categories)
        adapter.setDropDownViewResource(R.layout.item_spinner_white)
        spinnerKategoriTarget.adapter = adapter

        // Observers
        val targetsObserver = Observer<List<NetworkTarget>> { targets ->
            if (targets.isNotEmpty()) {
                rvTargets.visibility = View.VISIBLE
                tvNoTargets.visibility = View.GONE
                rvTargets.layoutManager = LinearLayoutManager(this)
                rvTargets.adapter = TargetAdapter(targets)
            } else {
                rvTargets.visibility = View.GONE
                tvNoTargets.visibility = View.VISIBLE
            }
        }
        targetViewModel.targets.observe(this, targetsObserver)
        
        val operationObserver = Observer<String?> { status ->
             if (status == "success_add") {
                  // Switch to Target Saya tab
                  toggleGroup.check(R.id.btnTargetSaya)
                  
                  // Clear actions handled in click listener or here?
                  // Better here to separate concerns, but we need reference to EditTexts which are below.
                  // For simplicity, let's just switch tab here. Clearing is done below in click listener? 
                  // No, click listener calls VM. VM updates status. So clearing should happen here or we keep refs.
                  // Since EditTexts are defined below, we might need to move this Observer block DOWN or access them later?
                  // Actually, we can define EditTexts earlier or access them.
                  // See next chunks.
                  
                  targetViewModel.clearOperationStatus()
             }
        }
        targetViewModel.operationStatus.observe(this, operationObserver)
        
        dialog.setOnDismissListener {
            targetViewModel.targets.removeObserver(targetsObserver)
            targetViewModel.operationStatus.removeObserver(operationObserver)
        }

        // Set initial state
        toggleGroup.check(R.id.btnTargetSaya)
        layoutTargetSaya.visibility = View.VISIBLE
        layoutBuatTargetBaru.visibility = View.GONE
        btnTargetSaya.strokeColor = purpleColor
        btnBuatTargetBaru.strokeColor = grayColor
        
        // Initial load
        ApiClient.auth.currentUser?.uid?.let { targetViewModel.loadTargets(it) }

        toggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                when (checkedId) {
                    R.id.btnTargetSaya -> {
                        layoutTargetSaya.visibility = View.VISIBLE
                        layoutBuatTargetBaru.visibility = View.GONE
                        btnTargetSaya.strokeColor = purpleColor
                        btnBuatTargetBaru.strokeColor = grayColor
                        val uid = ApiClient.auth.currentUser?.uid
                        if (uid != null) targetViewModel.loadTargets(uid)
                    }
                    R.id.btnBuatTargetBaru -> {
                        layoutTargetSaya.visibility = View.GONE
                        layoutBuatTargetBaru.visibility = View.VISIBLE
                        btnBuatTargetBaru.strokeColor = purpleColor
                        btnTargetSaya.strokeColor = grayColor
                    }
                }
            }
        }
        
        // --- Photo Picker Logic ---
        val layoutTargetFotoPlaceholder = dialog.findViewById<LinearLayout>(R.id.layoutTargetFotoPlaceholder)
        val ivRemoveTargetFoto = dialog.findViewById<ImageView>(R.id.ivRemoveTargetFoto)
        
        layoutTargetFotoPlaceholder.setOnClickListener {
            val options = arrayOf("Ambil Foto (Kamera)", "Pilih dari Galeri")
            AlertDialog.Builder(this)
                .setTitle("Tambah Foto Impian")
                .setItems(options) { _, which ->
                    if (which == 0) {
                        // Camera
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST_CODE)
                        } else {
                            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                            if (cameraIntent.resolveActivity(packageManager) != null) {
                                startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
                            } else {
                                Toast.makeText(this, "Kamera tidak tersedia", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        // Gallery
                        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE)
                    }
                }
                .show()
        }
        
        ivRemoveTargetFoto.setOnClickListener {
            currentProofBitmap = null
            updateTargetProofUI()
        }
        
        // --- Location Logic ---
        val btnTargetGetLocation = dialog.findViewById<Button>(R.id.btnTargetGetLocation)
        val btnTargetSearchLocation = dialog.findViewById<Button>(R.id.btnTargetSearchLocation)
        val btnTargetOpenMap = dialog.findViewById<Button>(R.id.btnTargetOpenMap)
        
        btnTargetGetLocation.setOnClickListener {
             if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                 ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), LOCATION_REQUEST_CODE)
            } else {
                getCurrentLocation()
            }
        }
        
        btnTargetSearchLocation.setOnClickListener {
            showSearchLocationInput(dialog)
        }
        
        btnTargetOpenMap.setOnClickListener {
             if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                 ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), LOCATION_REQUEST_CODE)
            } else {
                val intent = Intent(this, MapsActivity::class.java)
                startActivityForResult(intent, MAPS_REQUEST_CODE)
            }
        }
        
        val btnBuatTarget = dialog.findViewById<Button>(R.id.btnBuatTarget)
        val etNamaTarget = dialog.findViewById<EditText>(R.id.etNamaTarget)
        val etTargetNominal = dialog.findViewById<EditText>(R.id.etTargetNominal)
        val etJangkaWaktu = dialog.findViewById<EditText>(R.id.etJangkaWaktu)
        val etCatatanTarget = dialog.findViewById<EditText>(R.id.etCatatanTarget)
        
        btnBuatTarget.setOnClickListener {
            val nama = etNamaTarget.text.toString().trim()
            val nominalStr = etTargetNominal.text.toString().trim()
            val durasiStr = etJangkaWaktu.text.toString().trim()
            val catatan = etCatatanTarget.text.toString().trim()
            val kategori = spinnerKategoriTarget.selectedItem.toString()
            
            if (nama.isEmpty()) {
                etNamaTarget.error = "Nama target wajib diisi"
                return@setOnClickListener
            }
            if (nominalStr.isEmpty()) {
                etTargetNominal.error = "Nominal wajib diisi"
                return@setOnClickListener
            }
            if (durasiStr.isEmpty()) {
                etJangkaWaktu.error = "Durasi wajib diisi"
                return@setOnClickListener
            }
            
            val nominal = nominalStr.toDoubleOrNull() ?: 0.0
            val durasi = durasiStr.toIntOrNull() ?: 0
            
            val userId = ApiClient.auth.currentUser?.uid
            if (userId == null) {
                Toast.makeText(this, "Login dahulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val photoBase64 = if (currentProofBitmap != null) bitmapToBase64(currentProofBitmap!!) else null
            
            val target = NetworkTarget(
                name = nama,
                amount = nominal,
                durationMonths = durasi,
                category = kategori,
                note = catatan,
                photoStruct = photoBase64,
                location = currentLocationString,
                userId = userId
            )
            
            ApiClient.auth.currentUser?.uid?.let { uid ->
                 val target = NetworkTarget(
                    name = nama,
                    amount = nominal,
                    durationMonths = durasi,
                    category = kategori,
                    note = catatan,
                    photoStruct = photoBase64,
                    location = currentLocationString,
                    userId = uid
                 )
                 
                 // Clear inputs immediately (optimistic) or wait for observer?
                 // Let's clear here to be safe and responsive
                 etNamaTarget.text.clear()
                 etTargetNominal.text.clear()
                 etJangkaWaktu.text.clear()
                 etCatatanTarget.text.clear()
                 currentProofBitmap = null
                 updateTargetProofUI()
                 
                 targetViewModel.addTarget(target)
            }
        }

        ivClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }
    
     private fun showFinancialAnalysisDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_financial_analysis)

        val ivClose = dialog.findViewById<ImageView>(R.id.ivClose)
        val toggleGroup = dialog.findViewById<MaterialButtonToggleGroup>(R.id.toggleGroupAnalysis)
        val layoutOverview = dialog.findViewById<LinearLayout>(R.id.layoutOverview)
        val layoutPerbandingan = dialog.findViewById<LinearLayout>(R.id.layoutPerbandingan)
        val layoutKategori = dialog.findViewById<LinearLayout>(R.id.layoutKategori)
        val layoutProgressNabung = dialog.findViewById<LinearLayout>(R.id.layoutProgressNabung)

        toggleGroup.check(R.id.btnOverview)
        layoutOverview.visibility = View.VISIBLE
        layoutPerbandingan.visibility = View.GONE
        layoutKategori.visibility = View.GONE
        layoutProgressNabung.visibility = View.GONE

        // --- DATA PROCESSING & REAL VALUES ---
        
        // 1. Calculate General Overview (Current Month)
        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)
        
        val currentMonthTransactions = transactionList.filter { 
            val c = Calendar.getInstance().apply { time = it.date }
            c.get(Calendar.MONTH) == currentMonth && c.get(Calendar.YEAR) == currentYear
        }
        
        val totalIncome = currentMonthTransactions.filter { it.type == "Pemasukan" }.sumOf { it.amount }
        val totalExpense = currentMonthTransactions.filter { it.type == "Pengeluaran" }.sumOf { it.amount }
        val netSavings = totalIncome - totalExpense
        val savingsRate = if (totalIncome > 0) (netSavings / totalIncome) * 100 else 0.0

        val formatRp = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
        
        // Update Overview TextViews
        val tvTotalPemasukan = dialog.findViewById<TextView>(R.id.tvAnalysisTotalPemasukan)
        val tvTotalPengeluaran = dialog.findViewById<TextView>(R.id.tvAnalysisTotalPengeluaran)
        val tvNetSavings = dialog.findViewById<TextView>(R.id.tvAnalysisNetSavings)
        val tvSavingsRate = dialog.findViewById<TextView>(R.id.tvAnalysisSavingsRate)

        tvTotalPemasukan?.text = formatRp.format(totalIncome)
        tvTotalPengeluaran?.text = formatRp.format(totalExpense)
        tvNetSavings?.text = formatRp.format(netSavings)
        tvSavingsRate?.text = String.format("%.1f%%", savingsRate)

        // 2. Prepare Data for Bar Chart (Last 5 Months) & Line Chart (Savings Progress)
        val barMonths = ArrayList<String>()
        val incomeEntries = ArrayList<BarEntry>()
        val expenseEntries = ArrayList<BarEntry>()
        val savingsEntries = ArrayList<Entry>()
        
        for (i in 4 downTo 0) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.MONTH, -i)
            val monthIdx = cal.get(Calendar.MONTH)
            val year = cal.get(Calendar.YEAR)
            val monthName = SimpleDateFormat("MMM", Locale("in", "ID")).format(cal.time)
            
            barMonths.add(monthName)
            
            val monthTrans = transactionList.filter { 
                val c = Calendar.getInstance().apply { time = it.date }
                c.get(Calendar.MONTH) == monthIdx && c.get(Calendar.YEAR) == year
            }
            
            val mIncome = monthTrans.filter { it.type == "Pemasukan" }.sumOf { it.amount }
            val mExpense = monthTrans.filter { it.type == "Pengeluaran" }.sumOf { it.amount }
            
            // Adjust values for chart (e.g. in millions if needed, or simple raw)
            // Using raw values but maybe dividing by 1000 if too large? 
            // Let's use raw values but formated in label. BarEntry takes Float.
            
            incomeEntries.add(BarEntry((4-i).toFloat(), mIncome.toFloat()))
            expenseEntries.add(BarEntry((4-i).toFloat(), mExpense.toFloat()))
            
            val mSavings = mIncome - mExpense
            savingsEntries.add(Entry((4-i).toFloat(), mSavings.toFloat()))
        }

        // 3. Prepare Data for Pie Chart (Expense Categories - Current Month)
        val categoryExpenses = currentMonthTransactions
            .filter { it.type == "Pengeluaran" }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
        
        val pieEntries = ArrayList<PieEntry>()
        categoryExpenses.forEach { (cat, amount) ->
            if (amount > 0) {
                pieEntries.add(PieEntry(amount.toFloat(), cat))
            }
        }
        if (pieEntries.isEmpty()) {
            pieEntries.add(PieEntry(1f, "Belum ada data")) // Dummy to avoid crash
        }

        val barChart = dialog.findViewById<BarChart>(R.id.barChart)
        val pieChart = dialog.findViewById<PieChart>(R.id.pieChart)
        val lineChart = dialog.findViewById<LineChart>(R.id.lineChart)
        
        setupBarChart(barChart, barMonths, incomeEntries, expenseEntries)
        setupPieChart(pieChart, pieEntries)
        setupLineChart(lineChart, barMonths, savingsEntries)

        toggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                layoutOverview.visibility = if (checkedId == R.id.btnOverview) View.VISIBLE else View.GONE
                layoutPerbandingan.visibility = if (checkedId == R.id.btnPerbandingan) View.VISIBLE else View.GONE
                layoutKategori.visibility = if (checkedId == R.id.btnKategori) View.VISIBLE else View.GONE
                layoutProgressNabung.visibility = if (checkedId == R.id.btnProgressNabung) View.VISIBLE else View.GONE
            }
        }

        ivClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }


    private fun showLoginRegisterDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_login_register)

        val toggleGroup = dialog.findViewById<MaterialButtonToggleGroup>(R.id.toggleLoginRegister)
        val btnToggleMasuk = dialog.findViewById<Button>(R.id.btnToggleMasuk)
        val btnToggleDaftar = dialog.findViewById<Button>(R.id.btnToggleDaftar)
        val layoutLogin = dialog.findViewById<LinearLayout>(R.id.layoutLogin)
        val layoutRegister = dialog.findViewById<LinearLayout>(R.id.layoutRegister)
        val btnLogin = dialog.findViewById<Button>(R.id.btnLogin)
        
        // Login Views
        val etLoginEmail = dialog.findViewById<EditText>(R.id.etLoginEmail)
        val etLoginPassword = dialog.findViewById<EditText>(R.id.etLoginPassword)
        val tilLoginEmail = dialog.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilLoginEmail)
        val tilLoginPassword = dialog.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilLoginPassword)

        toggleGroup.check(R.id.btnToggleMasuk)

        toggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                if (checkedId == R.id.btnToggleMasuk) {
                    layoutLogin.visibility = View.VISIBLE
                    layoutRegister.visibility = View.GONE
                    btnToggleMasuk.setBackgroundColor(Color.parseColor("#4CAF50"))
                    btnToggleDaftar.setBackgroundColor(Color.parseColor("#333333"))
                } else if (checkedId == R.id.btnToggleDaftar) {
                    layoutLogin.visibility = View.GONE
                    layoutRegister.visibility = View.VISIBLE
                    btnToggleDaftar.setBackgroundColor(Color.parseColor("#4CAF50"))
                    btnToggleMasuk.setBackgroundColor(Color.parseColor("#333333"))
                }
            }
        }



        btnLogin.setOnClickListener {
            val email = etLoginEmail.text.toString().trim()
            val password = etLoginPassword.text.toString().trim()

            // Reset errors
            tilLoginEmail.error = null
            tilLoginPassword.error = null

            if (email.isEmpty() || password.isEmpty()) { 
                if (email.isEmpty()) tilLoginEmail.error = "Email wajib diisi"
                if (password.isEmpty()) tilLoginPassword.error = "Password wajib diisi"
                return@setOnClickListener
            }

            // Real Login Call
            ApiClient.login(email, password) { response ->
                if (response.status == "success") {
                    val user = response.data
                    if (user != null) {
                        validUsername = user.username
                        isLoggedIn = true
                        
                        // Save User Data
                        val prefs = getSharedPreferences("FinTrackPrefs", MODE_PRIVATE)
                        prefs.edit().putString("user_uid", user.id).putString("username", user.username).apply()

                        val tvLoginPrompt = findViewById<TextView>(R.id.tvLoginPrompt)
                        tvLoginPrompt.text = "Halo, ${user.username}"

                        Toast.makeText(this@MainActivity, "Login Berhasil!", Toast.LENGTH_SHORT).show()
                        
                        // Refresh data for this user
                        fetchTransactionsFromApi()
                        dialog.dismiss()
                    }
                } else {
                    Toast.makeText(this@MainActivity, "Login Gagal: ${response.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // --- REGISTER LOGIC ---
        val etRegisterUsername = dialog.findViewById<EditText>(R.id.etRegisterUsername)
        val etRegisterEmail = dialog.findViewById<EditText>(R.id.etRegisterEmail)
        val etRegisterPassword = dialog.findViewById<EditText>(R.id.etRegisterPassword)
        val tilRegisterUsername = dialog.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilRegisterUsername)
        val tilRegisterEmail = dialog.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilRegisterEmail)
        val tilRegisterPassword = dialog.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilRegisterPassword)
        val btnRegister = dialog.findViewById<Button>(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val username = etRegisterUsername.text.toString().trim()
            val email = etRegisterEmail.text.toString().trim()
            val password = etRegisterPassword.text.toString().trim()

            if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
               Toast.makeText(this, "Semua data wajib diisi", Toast.LENGTH_SHORT).show()
               return@setOnClickListener
            }
            
            // Real Register Call
            ApiClient.register(username, email, password) { response ->
               if (response.status == "success") {
                   Toast.makeText(this@MainActivity, "Registrasi Berhasil! Silakan Login.", Toast.LENGTH_SHORT).show()
                   
                   // Redirect to Login Tab
                   toggleGroup.check(R.id.btnToggleMasuk)
                   etLoginEmail.setText(email)
                   etLoginPassword.requestFocus()
               } else {
                   Toast.makeText(this@MainActivity, "Gagal: ${response.message}", Toast.LENGTH_SHORT).show()
               }
            }
        }
        // --- REGISTER LOGIC END ---

        dialog.show()
    }

    private fun showProfileDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_profile)
        
        // Make dialog background transparent to show rounded corners
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val tvProfileName = dialog.findViewById<TextView>(R.id.tvProfileName)
        val btnLogout = dialog.findViewById<Button>(R.id.btnLogout)

        tvProfileName.text = "Selamat datang, $validUsername!"

        btnLogout.setOnClickListener {
            // Clear data
            transactionList.clear()
            updateDashboard()

            // Clear Session
            val prefs = getSharedPreferences("FinTrackPrefs", MODE_PRIVATE)
            prefs.edit().clear().apply()
            ApiClient.auth.signOut() // Sign out from Firebase

            // Reset UI
            val tvLoginPrompt = findViewById<TextView>(R.id.tvLoginPrompt)
            tvLoginPrompt.text = "Masuk / Daftar"
            
            isLoggedIn = false
            
            Toast.makeText(this, "Berhasil keluar", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun setupBarChart(barChart: BarChart, months: ArrayList<String>, incomeList: ArrayList<BarEntry>, expenseList: ArrayList<BarEntry>) {
        val incomeDataSet = BarDataSet(incomeList, "Pemasukan").apply { color = Color.parseColor("#2E7D32") }
        val expenseDataSet = BarDataSet(expenseList, "Pengeluaran").apply { color = Color.parseColor("#C62828") }

        barChart.data = BarData(incomeDataSet, expenseDataSet).apply { barWidth = 0.3f }
        barChart.groupBars(0f, 0.3f, 0.05f)
        barChart.description.isEnabled = false
        barChart.legend.textColor = Color.WHITE
        
        // Custom Value Formatter to prevent scientific notation if values are large
        barChart.data.setValueFormatter(object: com.github.mikephil.charting.formatter.ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return formatCompactNumber(value)
            }
        })
        barChart.data.setValueTextColor(Color.WHITE)
        
        barChart.xAxis.apply {
            valueFormatter = IndexAxisValueFormatter(months)
            position = XAxis.XAxisPosition.BOTTOM
            textColor = Color.WHITE
            setDrawGridLines(false)
            granularity = 1f
            isGranularityEnabled = true
            axisMinimum = 0f
            axisMaximum = months.size.toFloat() // Ensure correct range
            setCenterAxisLabels(true) // Center labels for grouped bars
        }
        barChart.axisLeft.apply {
            textColor = Color.WHITE
            axisMinimum = 0f
            setDrawGridLines(true)
        }
        barChart.axisRight.isEnabled = false
        barChart.invalidate()
    }

    private fun setupPieChart(pieChart: PieChart, entries: ArrayList<PieEntry>) {
        // Dynamic Colors
        val colors = ArrayList<Int>()
        val baseColors = listOf("#C62828", "#FF8F00", "#1565C0", "#2E7D32", "#6A1B9A", "#00838F")
        for (i in entries.indices) {
            colors.add(Color.parseColor(baseColors[i % baseColors.size]))
        }
        
        val dataSet = PieDataSet(entries, "").apply {
            this.colors = colors
            valueTextColor = Color.WHITE
            valueTextSize = 12f
             valueFormatter = object: com.github.mikephil.charting.formatter.ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                     return formatCompactNumber(value)
                }
            }
        }
        pieChart.data = PieData(dataSet)
        pieChart.description.isEnabled = false
        pieChart.legend.isEnabled = true
        pieChart.legend.textColor = Color.WHITE
        pieChart.holeRadius = 40f
        pieChart.transparentCircleRadius = 45f
        pieChart.setDrawEntryLabels(false)
        pieChart.invalidate()
    }

    private fun setupLineChart(lineChart: LineChart, months: ArrayList<String>, entries: ArrayList<Entry>) {
        val dataSet = LineDataSet(entries, "Progress Tabungan Bulanan (Net)").apply {
            color = Color.parseColor("#2E7D32")
            setCircleColor(color)
            valueTextColor = Color.WHITE
            valueTextSize = 10f
            lineWidth = 2f
            valueFormatter = object: com.github.mikephil.charting.formatter.ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                     return formatCompactNumber(value)
                }
            }
        }
        lineChart.data = LineData(dataSet)
        
        lineChart.xAxis.apply {
            valueFormatter = IndexAxisValueFormatter(months)
            position = XAxis.XAxisPosition.BOTTOM
            textColor = Color.WHITE
            setDrawGridLines(false)
            granularity = 1f
            axisMinimum = 0f
            axisMaximum = (months.size - 1).toFloat()
        }
        lineChart.axisLeft.apply {
            textColor = Color.WHITE
            // Axis minimum can be negative if expenses > income
            setDrawGridLines(true)
        }
        lineChart.axisRight.isEnabled = false
        lineChart.description.isEnabled = false
        lineChart.legend.textColor = Color.WHITE
        lineChart.invalidate()
    }

    class TransactionAdapter(private val transactions: List<Transaction>, private val onImageClick: (Bitmap) -> Unit) : RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder>() {

        inner class TransactionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val title: TextView = itemView.findViewById(R.id.tvTransactionTitle)
            val date: TextView = itemView.findViewById(R.id.tvTransactionDate)
            val amount: TextView = itemView.findViewById(R.id.tvTransactionAmount)
            val location: TextView = itemView.findViewById(R.id.tvTransactionLocation)
            val cardProof: View = itemView.findViewById(R.id.cardProof)
            val ivProof: ImageView = itemView.findViewById(R.id.ivTransactionProof)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
            return TransactionViewHolder(view)
        }

        override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
            val transaction = transactions[position]
            holder.title.text = transaction.title

            val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("in", "ID"))
            holder.date.text = sdf.format(transaction.date)

            val format = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
            val formattedAmount = format.format(transaction.amount)

            if (transaction.type == "Pemasukan") {
                holder.amount.text = "+ $formattedAmount"
                holder.amount.setTextColor(Color.parseColor("#4CAF50"))
            } else {
                holder.amount.text = "- $formattedAmount"
                holder.amount.setTextColor(Color.parseColor("#F44336"))
            }
            
            if (transaction.proofImage != null) {
                holder.cardProof.visibility = View.VISIBLE
                holder.ivProof.setImageBitmap(transaction.proofImage)
                
                holder.itemView.setOnClickListener {
                    onImageClick(transaction.proofImage)
                }
            } else {
                holder.cardProof.visibility = View.GONE
                holder.itemView.setOnClickListener(null)
            }
            
            if (transaction.location != null) {
                holder.location.text = transaction.location
                holder.location.visibility = View.VISIBLE
            } else {
                holder.location.visibility = View.GONE
            }
        }

        override fun getItemCount(): Int = transactions.size
    }

    inner class TargetAdapter(private val targets: List<NetworkTarget>) : RecyclerView.Adapter<TargetAdapter.TargetViewHolder>() {

        inner class TargetViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val title: TextView = itemView.findViewById(R.id.tvTargetTitle)
            val nominal: TextView = itemView.findViewById(R.id.tvTargetNominal)
            val deadline: TextView = itemView.findViewById(R.id.tvTargetDeadline)
            val progress: ProgressBar = itemView.findViewById(R.id.progressTarget)
            val collected: TextView = itemView.findViewById(R.id.tvTargetCollected)
            val percentage: TextView = itemView.findViewById(R.id.tvTargetPercentage)
            val btnAddSavings: ImageView = itemView.findViewById(R.id.ivAddSavings) // Button Panah Atas
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TargetViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_planning_target, parent, false)
            return TargetViewHolder(view)
        }

        override fun onBindViewHolder(holder: TargetViewHolder, position: Int) {
            val target = targets[position]
            holder.title.text = target.name
            
            val format = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
            holder.nominal.text = "Target: ${format.format(target.amount)}"
            
            // Calculate Deadline
            val cal = Calendar.getInstance()
            cal.timeInMillis = target.createdAt
            cal.add(Calendar.MONTH, target.durationMonths)
            val sdf = SimpleDateFormat("d/M/yyyy", Locale("in", "ID"))
            holder.deadline.text = "Deadline: ${sdf.format(cal.time)}"
            
            // Dummy Progress for now (can be improved later)
            // Real Progress
            val currentAmount = target.currentAmount
            val progressPercent = if (target.amount > 0) ((currentAmount / target.amount) * 100).toInt() else 0
            
            holder.progress.progress = progressPercent
            holder.collected.text = "Terkumpul: ${format.format(currentAmount)}"
            holder.percentage.text = "$progressPercent%"
            
            if (progressPercent >= 100) {
                // Target Reached
                holder.percentage.text = "TERCAPAI!"
                holder.percentage.setTextColor(Color.parseColor("#4CAF50")) // Green
                holder.btnAddSavings.setImageResource(android.R.drawable.ic_menu_delete) // Change to Delete Icon
                holder.btnAddSavings.setColorFilter(Color.parseColor("#F44336")) // Red Tint
                
                holder.btnAddSavings.setOnClickListener {
                     AlertDialog.Builder(holder.itemView.context)
                        .setTitle("Target Tercapai! \uD83C\uDF89")
                        .setMessage("Selamat! Anda telah mencapai target '${target.name}'.\n\nApakah Anda ingin menghapus target ini dari daftar planning?")
                        .setPositiveButton("Hapus") { _, _ ->
                            if (target.id != null) {
                                val uid = ApiClient.auth.currentUser?.uid
                                if (uid != null) {
                                    targetViewModel.deleteTarget(target.id!!, uid)
                                    // Dashboard update can be observed or called here if needed, 
                                    // but target list update is automatic via LiveData.
                                    updateDashboard()
                                }
                            }
                        }
                        .setNegativeButton("Batal", null)
                        .show()
                }
            } else {
                // Not Reached
                holder.percentage.setTextColor(Color.parseColor("#4CAF50"))
                holder.btnAddSavings.setImageResource(R.drawable.ic_expand_less) // Back to arrow
                holder.btnAddSavings.setColorFilter(Color.parseColor("#CCCCCC")) // Grey Tint
                
                holder.btnAddSavings.setOnClickListener {
                    showAddSavingsDialog(target)
                }
            }
        }

        override fun getItemCount(): Int = targets.size
    }
    fun showImagePreviewDialog(bitmap: Bitmap) {
        val dialog = Dialog(this@MainActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        
        val imageView = ImageView(this@MainActivity)
        imageView.setImageBitmap(bitmap)
        imageView.adjustViewBounds = true
        imageView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        
        // Add some padding or background if needed
        dialog.setContentView(imageView)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        
        dialog.show()
    }

    private fun formatCompactNumber(value: Float): String {
        val number = value.toLong()
        if (number < 1000) return String.format("%.0f", value)
        val exp = (Math.log(number.toDouble()) / Math.log(1000.0)).toInt()
        val suffix = charArrayOf('K', 'M', 'B', 'T')[exp - 1]
        return String.format("%.1f%c", number / Math.pow(1000.0, exp.toDouble()), suffix)
    }
}

class TipsAdapter(private val tips: List<Tip>) : RecyclerView.Adapter<TipsAdapter.TipViewHolder>() {
    inner class TipViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.tvTipTitle)
        val description: TextView = itemView.findViewById(R.id.tvTipDescription)
        val layout: LinearLayout = itemView.findViewById(R.id.layoutTip)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TipViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tip, parent, false)
        return TipViewHolder(view)
    }

    override fun onBindViewHolder(holder: TipViewHolder, position: Int) {
        val tip = tips[position]
        holder.title.text = tip.title
        holder.description.text = tip.description
        holder.layout.setBackgroundColor(Color.parseColor(tip.color))
    }

    override fun getItemCount(): Int = tips.size
}
