package com.example.fintrack

import java.util.Calendar
import java.util.Date
import kotlin.math.max

class AiAnalyzer(private val transactions: List<Transaction>) {

    private val calendar = Calendar.getInstance()
    private val currentMonth = calendar.get(Calendar.MONTH)
    private val currentYear = calendar.get(Calendar.YEAR)

    // Filter data for current month only
    private val monthlyTransactions = transactions.filter {
        calendar.time = it.date
        calendar.get(Calendar.MONTH) == currentMonth && calendar.get(Calendar.YEAR) == currentYear
    }
    
    private val expenseTransactions = monthlyTransactions.filter { it.type == "Pengeluaran" }

    fun getAiAdvice(): String {
        if (expenseTransactions.isEmpty()) return "Belum ada data pengeluaran bulan ini. Hemat pangkal kaya! 🌱"

        val totalExpense = expenseTransactions.sumOf { it.amount }
        
        // 1. Check for single big spending (Title based)
        val spendingByTitle = expenseTransactions.groupBy { it.title.lowercase().trim() }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
        
        val topTitle = spendingByTitle.maxByOrNull { it.value }
        
        if (topTitle != null && topTitle.value > totalExpense * 0.4) {
            val percentage = (topTitle.value / totalExpense * 100).toInt()
            return "Perhatian! $percentage% pengeluaranmu bulan ini cuma buat '${topTitle.key}'. Coba dikurangi ya! ⚠️"
        }

        // 2. Check Daily Average
        val dayOfMonth = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        val dailyAverage = totalExpense / max(1, dayOfMonth)
        
        if (dailyAverage > 100000) { // Threshold example: 100k/day
            return "Rata-rata boros nih: ${formatRupiah(dailyAverage)}/hari. Rem sedikit yuk! 🚗"
        }

        return "Keuanganmu terpantau aman terkendali. Lanjutkan! 👍"
    }

    fun predictEndOfMonthExpense(): Double {
        if (expenseTransactions.size < 3) return 0.0

        // Prepare Data (x = day, y = cumulative expense)
        val dataPoints = expenseTransactions.sortedBy { it.date.time }
            .groupBy { 
                calendar.time = it.date
                calendar.get(Calendar.DAY_OF_MONTH) 
            }
            .toSortedMap()

        var n = 0.0
        var sumX = 0.0
        var sumY = 0.0
        var sumXY = 0.0
        var sumXX = 0.0
        
        var currentCumulative = 0.0
        
        dataPoints.forEach { (day, list) ->
            val dailyTotal = list.sumOf { it.amount }
            currentCumulative += dailyTotal
            
            val x = day.toDouble()
            val y = currentCumulative
            
            n += 1
            sumX += x
            sumY += y
            sumXY += (x * y)
            sumXX += (x * x)
        }

        // Linear Regression Formula
        // m = (n*sumXY - sumX*sumY) / (n*sumXX - sumX^2)
        val denominator = (n * sumXX - sumX * sumX)
        if (denominator == 0.0) return currentCumulative // Edge case: vertical line

        val m = (n * sumXY - sumX * sumY) / denominator
        val c = (sumY - m * sumX) / n

        // Predict for Last Day
        val lastDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH).toDouble()
        val prediction = m * lastDay + c
        
        return max(currentCumulative, prediction) // Prediction shouldn't be less than current
    }

    private fun formatRupiah(number: Double): String {
        val format = java.text.NumberFormat.getCurrencyInstance(java.util.Locale("in", "ID"))
        return format.format(number)
    }
}
