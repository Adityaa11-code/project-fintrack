package com.example.fintrack

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.text.NumberFormat
import java.util.Locale

class TargetViewModel : ViewModel() {

    private val _targets = MutableLiveData<List<NetworkTarget>>()
    val targets: LiveData<List<NetworkTarget>> get() = _targets

    private val _toastMessage = MutableLiveData<String>()
    val toastMessage: LiveData<String> get() = _toastMessage

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading
    
    // Status to trigger UI actions like dismissing dialogs. Using a simplified approach.
    // In strict MVVM, use SingleLiveEvent, but MutableLiveData is okay if reset.
    private val _operationStatus = MutableLiveData<String?>() // "success_add", "success_save", "error"
    val operationStatus: LiveData<String?> get() = _operationStatus

    fun clearOperationStatus() {
        _operationStatus.value = null
    }

    fun loadTargets(userId: String) {
        _isLoading.value = true
        ApiClient.getTargets(userId) { list ->
            _targets.value = list.sortedByDescending { it.createdAt }
            _isLoading.value = false
        }
    }

    fun addTarget(target: NetworkTarget) {
        _isLoading.value = true
        ApiClient.addTarget(target) { response ->
            _isLoading.value = false
            if (response.status == "success") {
                _toastMessage.value = "Target Berhasil Disimpan!"
                _operationStatus.value = "success_add"
                // Refresh list if user ID is available
                target.userId?.let { loadTargets(it) }
            } else {
                _toastMessage.value = "Gagal: ${response.message}"
            }
        }
    }

    fun deleteTarget(targetId: String, userId: String) {
        ApiClient.deleteTarget(targetId) { response ->
            if (response.status == "success") {
                _toastMessage.value = "Target dihapus"
                loadTargets(userId)
            } else {
                _toastMessage.value = "Gagal hapus: ${response.message}"
            }
        }
    }

    fun addSavings(target: NetworkTarget, amount: Double, userId: String) {
         // Cap amount to remaining needed
        val remainingNeeded = target.amount - target.currentAmount
        val actualSaveAmount: Double
        val refundAmount: Double
        
        if (amount > remainingNeeded) {
            actualSaveAmount = remainingNeeded
            refundAmount = amount - remainingNeeded
        } else {
            actualSaveAmount = amount
            refundAmount = 0.0
        }
        
        if (actualSaveAmount <= 0) {
             _toastMessage.value = "Target sudah tercapai!"
             return
        }

        // 1. Transaction
        val transaction = NetworkTransaction(
            title = "Tabungan: ${target.name}",
            amount = actualSaveAmount,
            date = System.currentTimeMillis(),
            note = "Setoran otomatis ke target ${target.name}",
            type = "Pengeluaran",
            category = "Investasi & Tabungan",
            userId = userId
        )
        
        ApiClient.addTransaction(transaction) { transResponse ->
            if (transResponse.status == "success") {
                // 2. Update Target
                val newAmount = target.currentAmount + actualSaveAmount
                val updatedTarget = target.copy(currentAmount = newAmount)
                
                ApiClient.updateTarget(updatedTarget) { targetResponse ->
                    if (targetResponse.status == "success") {
                         val formatRp = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
                         var msg = "Berhasil menabung ${formatRp.format(actualSaveAmount)}!"
                         if (refundAmount > 0) {
                             msg += "\nSisa ${formatRp.format(refundAmount)} dikembalikan ke saldo."
                         }
                         _toastMessage.value = msg
                         _operationStatus.value = "success_save"
                         
                         // Refresh List
                         loadTargets(userId)
                    } else {
                        _toastMessage.value = "Gagal update target: ${targetResponse.message}"
                    }
                }
            } else {
                 _toastMessage.value = "Gagal membuat transaksi: ${transResponse.message}"
            }
        }
    }
}
