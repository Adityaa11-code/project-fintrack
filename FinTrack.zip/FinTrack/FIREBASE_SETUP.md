# Firebase Firestore Setup Instructions

It looks like you are encountering a **PERMISSION_DENIED** error when trying to save a Target. This is because your Firebase Firestore Security Rules are blocking writing to the new `targets` collection.

To fix this, please follow these steps:

1.  Go to your **Firebase Console** (https://console.firebase.google.com).
2.  Select your project **FinTrack**.
3.  Navigate to **Firestore Database** > **Rules**.
4.  Update your rules to allow reading and writing to the `targets` collection.

Here is an example of rules that allow authenticated users to read and write to all collections (safe for development):

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

Or, specifically for the new collection:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // ... existing rules ...
    
    match /targets/{targetId} {
      allow read, write: if request.auth != null;
    }
    
    match /transactions/{transactionId} {
        allow read, write: if request.auth != null;
    }
    
    match /users/{userId} {
        allow read, write: if request.auth != null;
    }
  }
}
```

5.  Click **Publish**.
6.  Restart your app and try saving the target again.
