# FinTrack - Smart Financial Management App

## 👤 Group Members
*   **Aditya Akbar** - 00000103982

---

## 🔐 Login Credentials (Dummy Account)
Gunakan akun di bawah ini untuk menguji aplikasi secara langsung tanpa perlu mendaftar:

*   **Email:** `tester@fintrack.com`
*   **Password:** `admin12345`

*(Note: Silakan mendaftar akun baru jika ingin mencoba data yang benar-benar kosong).*

---

## 🛠️ Special Instructions & Testing Guide

Agar dapat menguji seluruh fitur aplikasi dengan optimal, harap perhatikan hal-hal berikut:

### 1. Koneksi Internet
Aplikasi ini menggunakan **Firebase Firestore & Authentication**. Pastikan perangkat terhubung ke internet untuk sinkronisasi data secara real-time.

### 2. Izin Perangkat (Runtime Permissions)
Saat pertama kali membuka aplikasi atau menggunakan fitur tertentu, sistem akan meminta izin:
*   **Camera:** Diperlukan untuk mengambil foto bukti transaksi dan foto target planning.
*   **Location (GPS):** Diperlukan untuk mencatat lokasi transaksi dan memilih lokasi di Google Maps.
*   Harap pilih **"Allow"** agar fitur berfungsi dengan benar.

### 3. Menguji Fitur AI Financial Advisor
Fitur AI Prediction memerlukan minimal **3 data transaksi pengeluaran** pada bulan berjalan untuk menghitung estimasi pengeluaran akhir bulan menggunakan algoritma *Linear Regression*.
*   **Cara Test:** Tambahkan 3 transaksi "Pengeluaran" dengan tanggal berbeda di bulan ini, maka baris "Prediksi Pengeluaran" pada kartu AI akan terupdate otomatis.

### 4. Integrasi Google Maps
Saat menambah transaksi atau target, klik tombol **"Lokasi"** untuk membuka `MapsActivity`.
*   Tunggu hingga peta dimuat (memerlukan Google Play Services).
*   Klik pada peta untuk menaruh marker, lalu klik **"Pilih Lokasi"**.
*   Alamat lengkap akan otomatis terisi menggunakan fitur *Reverse Geocoding*.

### 5. Bukti Transaksi (Camera)
Klik ikon **"Kamera"** pada dialog tambah transaksi. Foto yang diambil akan dikonversi menjadi *Base64* dan disimpan ke database secara aman.

### 6. Planning & Target (Tabungan Darurat)
*   Menu ini memungkinkan user membuat target tabungan dengan foto visual.
*   Klik **"Tambah Tabungan"** pada item target untuk menambah saldo tabungan khusus target tersebut. Progress bar akan bergerak secara otomatis sesuai persentase pencapaian.

---

## 🚀 Technology Stack
*   **Language:** Kotlin
*   **Architecture:** MVVM (Model-View-ViewModel)
*   **Database:** Firebase Cloud Firestore (NoSQL)
*   **Auth:** Firebase Authentication
*   **UI Components:** Material Design 3, ViewPager2, MPAndroidChart
*   **Native APIs:** Google Maps SDK, Fused Location Provider, Camera Hardware Interface
