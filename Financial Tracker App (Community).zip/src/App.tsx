import { ChangeEvent, FormEvent, useEffect, useMemo, useRef, useState } from "react";

type View = "home" | "analytics" | "transactions" | "settings";
type TransactionType = "expense" | "income";

type Category = {
  id: string;
  label: string;
  icon: IconName;
  color: string;
};

type Transaction = {
  id: number;
  title: string;
  category: string;
  type: TransactionType;
  amount: number;
  date: string;
  note?: string;
  receipt?: string;
};

type IconName =
  | "home"
  | "chart"
  | "wallet"
  | "settings"
  | "plus"
  | "bell"
  | "arrowUp"
  | "arrowDown"
  | "dots"
  | "search"
  | "food"
  | "transport"
  | "shopping"
  | "bills"
  | "health"
  | "fun"
  | "education"
  | "travel"
  | "homeCategory"
  | "gift"
  | "salary"
  | "camera"
  | "close"
  | "calendar"
  | "chevron";

const categories: Category[] = [
  { id: "food", label: "Food & dining", icon: "food", color: "#f5a65b" },
  { id: "transport", label: "Transport", icon: "transport", color: "#6bb7bc" },
  { id: "shopping", label: "Shopping", icon: "shopping", color: "#8c75d6" },
  { id: "bills", label: "Bills", icon: "bills", color: "#e77872" },
  { id: "health", label: "Health", icon: "health", color: "#64ad7f" },
  { id: "fun", label: "Entertainment", icon: "fun", color: "#db76a6" },
  { id: "education", label: "Education", icon: "education", color: "#598ccc" },
  { id: "travel", label: "Travel", icon: "travel", color: "#e19459" },
  { id: "housing", label: "Housing", icon: "homeCategory", color: "#5b9e93" },
  { id: "gifts", label: "Gifts", icon: "gift", color: "#bf7a9f" },
];

const starterTransactions: Transaction[] = [
  { id: 1, title: "Apartment rent", category: "bills", type: "expense", amount: 2470, date: "Today, 9:12 AM", note: "November rent" },
  { id: 2, title: "Monthly salary", category: "salary", type: "income", amount: 18500, date: "Today, 8:30 AM" },
  { id: 3, title: "Weekend groceries", category: "food", type: "expense", amount: 1380, date: "Yesterday, 5:42 PM", receipt: "receipt" },
  { id: 4, title: "New headphones", category: "shopping", type: "expense", amount: 2150, date: "Nov 14, 2:18 PM", receipt: "receipt" },
  { id: 5, title: "Ride to work", category: "transport", type: "expense", amount: 940, date: "Nov 13, 7:40 AM" },
  { id: 6, title: "Dinner with friends", category: "food", type: "expense", amount: 780, date: "Nov 12, 8:10 PM", note: "Birthday dinner" },
];

const currency = new Intl.NumberFormat("en-PH", {
  style: "currency",
  currency: "PHP",
  maximumFractionDigits: 0,
});

const iconPaths: Record<IconName, React.ReactNode> = {
  home: <><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V21h14V9.5M9 21v-7h6v7" /></>,
  chart: <><path d="M4 19V9M10 19V5M16 19v-7M22 19H2" /></>,
  wallet: <><path d="M3 7h16a2 2 0 0 1 2 2v10H5a2 2 0 0 1-2-2V7Z" /><path d="M3 7V5a2 2 0 0 1 2-2h12v4M16 12h5v4h-5a2 2 0 0 1 0-4Z" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V21h-4v-.09A1.7 1.7 0 0 0 8.94 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.57 15 1.7 1.7 0 0 0 3 14H3v-4h.09A1.7 1.7 0 0 0 4.6 8.94a1.7 1.7 0 0 0-.34-1.88L4.2 7l2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.57 1.7 1.7 0 0 0 10 3h4v.09a1.7 1.7 0 0 0 1.06 1.51 1.7 1.7 0 0 0 1.88-.34L17 4.2 19.83 7l-.06.06A1.7 1.7 0 0 0 19.43 9 1.7 1.7 0 0 0 21 10h.09v4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
  plus: <><path d="M12 5v14M5 12h14" /></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
  arrowUp: <><path d="m7 11 5-5 5 5M12 6v12" /></>,
  arrowDown: <><path d="m7 13 5 5 5-5M12 18V6" /></>,
  dots: <><circle cx="5" cy="12" r="1" fill="currentColor" stroke="none" /><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" /><circle cx="19" cy="12" r="1" fill="currentColor" stroke="none" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
  food: <><path d="M7 3v8M4 3v5a3 3 0 0 0 6 0V3M7 11v10M16 3v18M16 3c4 2 4 8 0 10" /></>,
  transport: <><path d="M5 17h14M6 17l1-9h10l1 9M8 8l1-3h6l1 3" /><circle cx="8" cy="18" r="2" /><circle cx="16" cy="18" r="2" /></>,
  shopping: <><circle cx="9" cy="20" r="1" /><circle cx="18" cy="20" r="1" /><path d="M3 4h2l2.5 11h11l2-7H7" /></>,
  bills: <><path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z" /><path d="M9 8h6M9 12h6" /></>,
  health: <><path d="M20.8 5.7a5.5 5.5 0 0 0-7.8 0L12 6.8l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 22l8.8-8.5a5.5 5.5 0 0 0 0-7.8Z" /><path d="M7 13h3l1-3 2 6 1-3h3" /></>,
  fun: <><path d="M8 8h8a5 5 0 0 1 4.8 6.4l-1 3.2a2 2 0 0 1-3.5.7L14 15h-4l-2.3 3.3a2 2 0 0 1-3.5-.7l-1-3.2A5 5 0 0 1 8 8Z" /><path d="M8 11v4M6 13h4M16 12h.01M18 14h.01" /></>,
  education: <><path d="m3 10 9-5 9 5-9 5-9-5Z" /><path d="M7 12.5V17c3 2 7 2 10 0v-4.5M21 10v6" /></>,
  travel: <><path d="M22 2 9 15M15 5l4 4M11 13l-2 8-3-3-3-3 8-2ZM4 10l-2-2 5-2M14 20l2 2 2-5" /></>,
  homeCategory: <><path d="m3 10 9-7 9 7v11H3V10Z" /><path d="M9 21v-7h6v7" /></>,
  gift: <><path d="M3 9h18v12H3V9ZM12 9v12M2 9h20V5H2v4Z" /><path d="M12 5c-1-4-7-4-6 0 1 2 6 0 6 0Zm0 0c1-4 7-4 6 0-1 2-6 0-6 0Z" /></>,
  salary: <><rect x="3" y="6" width="18" height="14" rx="2" /><path d="M8 6V4h8v2M8 13h8" /></>,
  camera: <><path d="M4 7h3l2-3h6l2 3h3a2 2 0 0 1 2 2v10H2V9a2 2 0 0 1 2-2Z" /><circle cx="12" cy="13" r="4" /></>,
  close: <><path d="m6 6 12 12M18 6 6 18" /></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
  chevron: <><path d="m9 18 6-6-6-6" /></>,
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {iconPaths[name]}
    </svg>
  );
}

function categoryFor(id: string): Category {
  if (id === "salary") return { id, label: "Income", icon: "salary", color: "#67a27d" };
  if (id.startsWith("custom:")) {
    return {
      id,
      label: decodeURIComponent(id.slice(7)),
      icon: "wallet",
      color: "#5b9e93",
    };
  }
  return categories.find((category) => category.id === id) ?? categories[0];
}

function AppButton({
  children,
  className = "",
  type = "button",
  onClick,
  ariaLabel,
}: {
  children: React.ReactNode;
  className?: string;
  type?: "button" | "submit";
  onClick?: () => void;
  ariaLabel?: string;
}) {
  return <button type={type} className={className} onClick={onClick} aria-label={ariaLabel}>{children}</button>;
}

function NavButton({ icon, label, active, onClick }: { icon: IconName; label: string; active: boolean; onClick: () => void }) {
  return (
    <AppButton className={`nav-button ${active ? "active" : ""}`} onClick={onClick}>
      <Icon name={icon} size={22} />
      <span>{label}</span>
    </AppButton>
  );
}

function TransactionRow({ transaction }: { transaction: Transaction }) {
  const category = categoryFor(transaction.category);
  return (
    <article className="transaction-row">
      <div className="category-icon" style={{ backgroundColor: `${category.color}1f`, color: category.color }}>
        <Icon name={category.icon} size={21} />
      </div>
      <div className="transaction-info">
        <div className="transaction-title-line">
          <strong>{transaction.title}</strong>
          {transaction.receipt && <span className="receipt-mark" title="Receipt attached"><Icon name="camera" size={12} /></span>}
        </div>
        <span>{category.label} · {transaction.date}</span>
      </div>
      <strong className={transaction.type === "income" ? "positive" : "negative"}>
        {transaction.type === "income" ? "+" : "−"}{currency.format(transaction.amount)}
      </strong>
    </article>
  );
}

function SummaryCard({ label, amount, icon, tone }: { label: string; amount: number; icon: IconName; tone: string }) {
  return (
    <article className={`summary-card ${tone}`}>
      <div className="summary-label"><span className="mini-icon"><Icon name={icon} size={15} /></span>{label}</div>
      <strong>{currency.format(amount)}</strong>
      <span className="summary-change">{tone === "income" ? "↑ 8.2% from last month" : "↓ 3.1% from last month"}</span>
    </article>
  );
}

function Dashboard({
  transactions,
  expense,
  income,
  onAdd,
  onViewAll,
}: {
  transactions: Transaction[];
  expense: number;
  income: number;
  onAdd: () => void;
  onViewAll: () => void;
}) {
  const balance = income - expense;
  return (
    <>
      <header className="topbar">
        <div>
          <span className="eyebrow">NOVEMBER 2024</span>
          <h1>Good morning, Sofia</h1>
        </div>
        <AppButton className="icon-button" ariaLabel="Notifications"><Icon name="bell" size={21} /><span className="notification-dot" /></AppButton>
      </header>

      <section className="balance-card">
        <div className="balance-copy">
          <span>Available balance</span>
          <strong>{currency.format(balance)}</strong>
          <small>You’re on track this month</small>
        </div>
        <div className="balance-orbit" aria-hidden="true"><span /><span /><span /></div>
      </section>

      <section className="summary-grid">
        <SummaryCard label="Income" amount={income} icon="arrowDown" tone="income" />
        <SummaryCard label="Expenses" amount={expense} icon="arrowUp" tone="expense" />
      </section>

      <section className="panel spending-panel">
        <div className="section-heading">
          <div><span className="eyebrow">OVERVIEW</span><h2>Spending snapshot</h2></div>
          <AppButton className="text-button" onClick={onViewAll}>View analytics <Icon name="chevron" size={15} /></AppButton>
        </div>
        <div className="snapshot-layout">
          <div className="donut" style={{ "--total": `"${currency.format(expense)}"` } as React.CSSProperties}>
            <div><span>Spent</span><strong>{currency.format(expense)}</strong></div>
          </div>
          <div className="spending-bars">
            {[
              { label: "Bills & utilities", amount: 2470, color: "#e77872" },
              { label: "Shopping", amount: 2150, color: "#8c75d6" },
              { label: "Food & dining", amount: 2160, color: "#f5a65b" },
              { label: "Transport", amount: 940, color: "#6bb7bc" },
            ].map((item) => (
              <div className="spending-item" key={item.label}>
                <div><span className="legend-dot" style={{ backgroundColor: item.color }} /><span>{item.label}</span><strong>{currency.format(item.amount)}</strong></div>
                <div className="progress-track"><span style={{ width: `${Math.min(100, (item.amount / 2470) * 100)}%`, backgroundColor: item.color }} /></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="panel recent-panel">
        <div className="section-heading">
          <div><span className="eyebrow">ACTIVITY</span><h2>Recent transactions</h2></div>
          <AppButton className="text-button" onClick={onViewAll}>View all <Icon name="chevron" size={15} /></AppButton>
        </div>
        <div className="transaction-list">
          {transactions.slice(0, 5).map((transaction) => <TransactionRow key={transaction.id} transaction={transaction} />)}
        </div>
      </section>

      <AppButton className="desktop-add" onClick={onAdd}><Icon name="plus" size={20} /> Add transaction</AppButton>
    </>
  );
}

function Analytics({ transactions, expense, income }: { transactions: Transaction[]; expense: number; income: number }) {
  const [metric, setMetric] = useState<TransactionType>("expense");
  const categoryTotals = useMemo(() => {
    const totals = new Map<string, number>();
    transactions.filter((item) => item.type === metric).forEach((item) => totals.set(item.category, (totals.get(item.category) ?? 0) + item.amount));
    return [...totals.entries()].sort((a, b) => b[1] - a[1]);
  }, [metric, transactions]);
  const total = metric === "expense" ? expense : income;

  return (
    <>
      <header className="topbar">
        <div><span className="eyebrow">INSIGHTS</span><h1>Analytics</h1></div>
        <AppButton className="month-button"><Icon name="calendar" size={17} /> November</AppButton>
      </header>

      <div className="segmented">
        <AppButton className={metric === "expense" ? "active" : ""} onClick={() => setMetric("expense")}>Expenses</AppButton>
        <AppButton className={metric === "income" ? "active" : ""} onClick={() => setMetric("income")}>Income</AppButton>
      </div>

      <section className="panel chart-panel">
        <div className="section-heading">
          <div><span className="eyebrow">MONTHLY FLOW</span><h2>{metric === "expense" ? "Expense activity" : "Income activity"}</h2></div>
          <strong className="chart-total">{currency.format(total)}</strong>
        </div>
        <div className="bar-chart">
          {[46, 68, 51, 82, 59, 91, 72, 88, 63, 77, 54, 70].map((height, index) => (
            <div className="bar-column" key={index}>
              <span style={{ height: `${metric === "income" ? Math.min(96, height + 14) : height}%` }} />
              <small>{index % 2 === 0 ? `${index + 1}` : ""}</small>
            </div>
          ))}
        </div>
        <div className="chart-caption"><span>Nov 1</span><span>Nov 30</span></div>
      </section>

      <section className="panel category-panel">
        <div className="section-heading">
          <div><span className="eyebrow">BREAKDOWN</span><h2>{metric === "expense" ? "Spending" : "Income"} by category</h2></div>
        </div>
        <div className="category-breakdown">
          <div className={`donut large ${metric === "income" ? "income-donut" : ""}`}>
            <div><span>Total</span><strong>{currency.format(total)}</strong></div>
          </div>
          <div className="category-list">
            {categoryTotals.map(([id, amount]) => {
              const category = categoryFor(id);
              return (
                <div className="category-stat" key={id}>
                  <span className="legend-dot" style={{ backgroundColor: category.color }} />
                  <div><strong>{category.label}</strong><span>{Math.round((amount / total) * 100)}% of total</span></div>
                  <strong>{currency.format(amount)}</strong>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
}

function Transactions({ transactions }: { transactions: Transaction[] }) {
  const [query, setQuery] = useState("");
  const filtered = transactions.filter((item) => `${item.title} ${categoryFor(item.category).label}`.toLowerCase().includes(query.toLowerCase()));
  return (
    <>
      <header className="topbar">
        <div><span className="eyebrow">HISTORY</span><h1>Transactions</h1></div>
        <AppButton className="month-button"><Icon name="calendar" size={17} /> November</AppButton>
      </header>
      <label className="search-box">
        <Icon name="search" size={19} />
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search transactions" />
      </label>
      <section className="panel full-list">
        <div className="date-divider"><strong>November</strong><span>{filtered.length} entries</span></div>
        {filtered.length ? filtered.map((transaction) => <TransactionRow key={transaction.id} transaction={transaction} />) : <div className="empty-state">No matching transactions found.</div>}
      </section>
    </>
  );
}

function SettingsView() {
  return (
    <>
      <header className="topbar"><div><span className="eyebrow">PREFERENCES</span><h1>Settings</h1></div></header>
      <section className="profile-card panel">
        <div className="avatar">SD</div>
        <div><h2>Sofia dela Cruz</h2><span>Personal account</span></div>
      </section>
      <section className="panel settings-list">
        {[
          ["Currency", "Philippine peso (PHP)"],
          ["Monthly budget", currency.format(15000)],
          ["Receipt storage", "On this device"],
          ["Notifications", "Weekly summary"],
        ].map(([label, value]) => <div className="settings-row" key={label}><div><strong>{label}</strong><span>{value}</span></div><Icon name="chevron" size={18} /></div>)}
      </section>
    </>
  );
}

function AddTransaction({
  onClose,
  onSave,
}: {
  onClose: () => void;
  onSave: (transaction: Omit<Transaction, "id" | "date">) => void;
}) {
  const [type, setType] = useState<TransactionType>("expense");
  const [selectedCategory, setSelectedCategory] = useState("food");
  const [amount, setAmount] = useState("");
  const [title, setTitle] = useState("");
  const [note, setNote] = useState("");
  const [receipt, setReceipt] = useState("");
  const [newCategory, setNewCategory] = useState("");
  const [showCategoryInput, setShowCategoryInput] = useState(false);
  const [customCategories, setCustomCategories] = useState<Category[]>(() => {
    try {
      const saved = localStorage.getItem("peso-custom-categories");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const fileRef = useRef<HTMLInputElement>(null);
  const availableCategories = [...categories, ...customCategories];

  const addCustomCategory = () => {
    const label = newCategory.trim();
    if (!label) return;
    const id = `custom:${encodeURIComponent(label)}`;
    const category: Category = { id, label, icon: "wallet", color: "#5b9e93" };
    const updated = customCategories.some((item) => item.id === id)
      ? customCategories
      : [...customCategories, category];
    setCustomCategories(updated);
    localStorage.setItem("peso-custom-categories", JSON.stringify(updated));
    setSelectedCategory(id);
    setNewCategory("");
    setShowCategoryInput(false);
  };

  const handleReceipt = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setReceipt(String(reader.result));
    reader.readAsDataURL(file);
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    const parsedAmount = Number(amount);
    if (!parsedAmount || !title.trim()) return;
    onSave({
      title: title.trim(),
      category: type === "income" ? "salary" : selectedCategory,
      type,
      amount: parsedAmount,
      note: note.trim(),
      receipt,
    });
  };

  return (
    <div className="modal-backdrop" role="presentation">
      <form className="add-sheet" onSubmit={handleSubmit}>
        <div className="sheet-handle" />
        <div className="sheet-header">
          <div><span className="eyebrow">NEW ENTRY</span><h2>Add transaction</h2></div>
          <AppButton className="icon-button" onClick={onClose} ariaLabel="Close"><Icon name="close" size={20} /></AppButton>
        </div>
        <div className="segmented">
          <AppButton className={type === "expense" ? "active" : ""} onClick={() => setType("expense")}>Expense</AppButton>
          <AppButton className={type === "income" ? "active" : ""} onClick={() => setType("income")}>Income</AppButton>
        </div>
        <label className="amount-input">
          <span>Amount</span>
          <div><strong>₱</strong><input inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value.replace(/[^\d.]/g, ""))} placeholder="0" autoFocus /></div>
        </label>
        <label className="field">
          <span>{type === "income" ? "Income source" : "What did you buy?"}</span>
          <input value={title} onChange={(event) => setTitle(event.target.value)} placeholder={type === "income" ? "e.g. Monthly salary" : "e.g. Weekly groceries"} />
        </label>
        {type === "expense" && (
          <fieldset className="category-picker">
            <legend>Choose a category</legend>
            <div>
              {availableCategories.map((category) => (
                <AppButton className={selectedCategory === category.id ? "selected" : ""} key={category.id} onClick={() => setSelectedCategory(category.id)}>
                  <span style={{ backgroundColor: `${category.color}1f`, color: category.color }}><Icon name={category.icon} size={20} /></span>
                  <small>{category.label}</small>
                </AppButton>
              ))}
              <AppButton className="add-category-tile" onClick={() => setShowCategoryInput(true)}>
                <span><Icon name="plus" size={20} /></span>
                <small>New category</small>
              </AppButton>
            </div>
            {showCategoryInput && (
              <div className="new-category-row">
                <input
                  value={newCategory}
                  onChange={(event) => setNewCategory(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      event.preventDefault();
                      addCustomCategory();
                    }
                  }}
                  placeholder="Category name"
                  autoFocus
                />
                <AppButton onClick={addCustomCategory}>Add</AppButton>
              </div>
            )}
          </fieldset>
        )}
        <label className="field">
          <span>Notes <small>Optional</small></span>
          <textarea value={note} onChange={(event) => setNote(event.target.value)} placeholder="Add a helpful note..." rows={2} />
        </label>
        <div className="receipt-field">
          <span>Receipt <small>Optional</small></span>
          <input ref={fileRef} type="file" accept="image/*" onChange={handleReceipt} hidden />
          {receipt ? (
            <div className="receipt-preview">
              <img src={receipt} alt="Receipt preview" />
              <div><strong>Receipt attached</strong><span>Tap to choose a different image</span></div>
              <AppButton className="text-button" onClick={() => fileRef.current?.click()}>Change</AppButton>
            </div>
          ) : (
            <AppButton className="receipt-upload" onClick={() => fileRef.current?.click()}>
              <span><Icon name="camera" size={20} /></span>
              <div><strong>Add receipt photo</strong><small>JPG or PNG</small></div>
              <Icon name="chevron" size={18} />
            </AppButton>
          )}
        </div>
        <AppButton className="save-button" type="submit">Save {type}</AppButton>
      </form>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState<View>("home");
  const [showAdd, setShowAdd] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem("peso-transactions");
      return saved ? JSON.parse(saved) : starterTransactions;
    } catch {
      return starterTransactions;
    }
  });
  const totals = useMemo(() => transactions.reduce((result, transaction) => {
    result[transaction.type] += transaction.amount;
    return result;
  }, { expense: 0, income: 0 }), [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem("peso-transactions", JSON.stringify(transactions));
    } catch {
      // Keep the tracker usable if browser storage is full or unavailable.
    }
  }, [transactions]);

  const saveTransaction = (transaction: Omit<Transaction, "id" | "date">) => {
    setTransactions((current) => [{ ...transaction, id: Date.now(), date: "Just now" }, ...current]);
    setShowAdd(false);
    setView("home");
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span><Icon name="wallet" size={21} /></span><strong>Peso</strong></div>
        <nav>
          <NavButton icon="home" label="Overview" active={view === "home"} onClick={() => setView("home")} />
          <NavButton icon="chart" label="Analytics" active={view === "analytics"} onClick={() => setView("analytics")} />
          <NavButton icon="wallet" label="Transactions" active={view === "transactions"} onClick={() => setView("transactions")} />
          <NavButton icon="settings" label="Settings" active={view === "settings"} onClick={() => setView("settings")} />
        </nav>
        <div className="budget-mini">
          <span>Monthly budget</span><strong>{currency.format(totals.expense)} <small>/ ₱15,000</small></strong>
          <div><span style={{ width: `${Math.min(100, (totals.expense / 15000) * 100)}%` }} /></div>
        </div>
      </aside>

      <main>
        {view === "home" && <Dashboard transactions={transactions} expense={totals.expense} income={totals.income} onAdd={() => setShowAdd(true)} onViewAll={() => setView("analytics")} />}
        {view === "analytics" && <Analytics transactions={transactions} expense={totals.expense} income={totals.income} />}
        {view === "transactions" && <Transactions transactions={transactions} />}
        {view === "settings" && <SettingsView />}
      </main>

      <nav className="mobile-nav">
        <NavButton icon="home" label="Home" active={view === "home"} onClick={() => setView("home")} />
        <NavButton icon="chart" label="Charts" active={view === "analytics"} onClick={() => setView("analytics")} />
        <AppButton className="mobile-add" onClick={() => setShowAdd(true)} ariaLabel="Add transaction"><Icon name="plus" size={28} /></AppButton>
        <NavButton icon="wallet" label="Activity" active={view === "transactions"} onClick={() => setView("transactions")} />
        <NavButton icon="settings" label="Settings" active={view === "settings"} onClick={() => setView("settings")} />
      </nav>

      {showAdd && <AddTransaction onClose={() => setShowAdd(false)} onSave={saveTransaction} />}
    </div>
  );
}
